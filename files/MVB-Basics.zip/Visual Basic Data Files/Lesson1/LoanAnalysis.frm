VERSION 5.00
Begin VB.Form frmMainForm 
   Caption         =   "Loan Analysis"
   ClientHeight    =   3135
   ClientLeft      =   9420
   ClientTop       =   915
   ClientWidth     =   5160
   LinkTopic       =   "Form1"
   ScaleHeight     =   3135
   ScaleWidth      =   5160
   Begin VB.CommandButton cmdExit 
      Cancel          =   -1  'True
      Caption         =   "Exit"
      Height          =   495
      Left            =   2760
      TabIndex        =   13
      Top             =   2280
      Width           =   1215
   End
   Begin VB.CommandButton cmdCalculate 
      Caption         =   "Calculate"
      Default         =   -1  'True
      Height          =   495
      Left            =   1200
      TabIndex        =   12
      Top             =   2280
      Width           =   1215
   End
   Begin VB.TextBox txtYears 
      Alignment       =   1  'Right Justify
      Height          =   285
      Left            =   3480
      TabIndex        =   2
      Text            =   "0"
      Top             =   600
      Width           =   1335
   End
   Begin VB.TextBox txtAnnualInterestRate 
      Alignment       =   1  'Right Justify
      Height          =   285
      Left            =   1920
      TabIndex        =   1
      Text            =   "0"
      Top             =   600
      Width           =   1335
   End
   Begin VB.TextBox txtLoanAmount 
      Alignment       =   1  'Right Justify
      Height          =   285
      Left            =   360
      TabIndex        =   0
      Text            =   "0"
      Top             =   600
      Width           =   1335
   End
   Begin VB.Label lblTotalPayments 
      Alignment       =   1  'Right Justify
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "0"
      Height          =   255
      Left            =   3480
      TabIndex        =   11
      Top             =   1560
      Width           =   1335
   End
   Begin VB.Label lblTotalPaymentsLabel 
      Caption         =   "Total of Payments"
      Height          =   255
      Left            =   3480
      TabIndex        =   10
      Top             =   1320
      Width           =   1575
   End
   Begin VB.Label lblTotalInterest 
      Alignment       =   1  'Right Justify
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "0"
      Height          =   255
      Left            =   1920
      TabIndex        =   9
      Top             =   1560
      Width           =   1335
   End
   Begin VB.Label lblTotalInterestLabel 
      Caption         =   "Total Interest"
      Height          =   255
      Left            =   1920
      TabIndex        =   8
      Top             =   1320
      Width           =   1215
   End
   Begin VB.Label lblPayment 
      Alignment       =   1  'Right Justify
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "0"
      Height          =   255
      Left            =   360
      TabIndex        =   7
      Top             =   1560
      Width           =   1335
   End
   Begin VB.Label lblPaymentLabel 
      Caption         =   "Payment"
      Height          =   255
      Left            =   360
      TabIndex        =   6
      Top             =   1320
      Width           =   1215
   End
   Begin VB.Label lblYears 
      Caption         =   "Years"
      Height          =   255
      Left            =   3480
      TabIndex        =   5
      Top             =   360
      Width           =   1215
   End
   Begin VB.Label lblAnnualInterestRate 
      Caption         =   "Annual Rate (in %)"
      Height          =   255
      Left            =   1920
      TabIndex        =   4
      Top             =   360
      Width           =   1455
   End
   Begin VB.Label lblLoanAmount 
      Caption         =   "Loan Amount"
      Height          =   255
      Left            =   360
      TabIndex        =   3
      Top             =   360
      Width           =   1215
   End
End
Attribute VB_Name = "frmMainForm"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdCalculate_Click()
    
    'Variables used in calculations
    Dim sngMonthlyInterestRate As Single
    Dim sngNumberOfPayments As Single
    Dim curMonthlyPayment As Currency
    Dim curTotalOfPayments As Currency
    Dim curTotalInterest As Currency
    
    'Variables used for output
    Dim strMonthlyPayment As String
    Dim strTotalOfPayments As String
    Dim strTotalInterest As String

    'If error occurs, go to end of the routine to print error message
    On Error GoTo ErrorHandler

    'Calculate the monthly interest rate and number of monthly payments
    sngMonthlyInterestRate = txtAnnualInterestRate / 1200
    sngNumberOfPayments = txtYears * 12

    'Calculate the payment, total interest, and total of payments
    curMonthlyPayment = txtLoanAmount * sngMonthlyInterestRate _
    / (1 - (1 + sngMonthlyInterestRate) ^ (-sngNumberOfPayments))
    curTotalOfPayments = curMonthlyPayment * sngNumberOfPayments
    curTotalInterest = curTotalOfPayments - txtLoanAmount

    'Format the calculated values into dollars and cents
    strMonthlyPayment = Format(curMonthlyPayment, "$######.00")
    strTotalOfPayments = Format(curTotalOfPayments, "$######.00")
    strTotalInterest = Format(curTotalInterest, "$######.00")

    'Update the output labels to display the calculated amounts
    lblPayment = strMonthlyPayment
    lblTotalPayments = strTotalOfPayments
    lblTotalInterest = strTotalInterest
    
    Exit Sub 'Exit this subroutine if no error occurred
    
'Error handler
ErrorHandler:
    MsgBox ("The values you entered resulted in an error. Try Again.")
    Exit Sub
End Sub

Private Sub cmdExit_Click()
    End
End Sub

Private Sub txtAnnualInterestRate_GotFocus()
    txtAnnualInterestRate.SelStart = 0
    txtAnnualInterestRate.SelLength = Len(txtAnnualInterestRate.Text)
End Sub

Private Sub txtLoanAmount_GotFocus()
    txtLoanAmount.SelStart = 0
    txtLoanAmount.SelLength = Len(txtLoanAmount.Text)
End Sub

Private Sub txtYears_GotFocus()
    txtYears.SelStart = 0
    txtYears.SelLength = Len(txtYears.Text)
End Sub
