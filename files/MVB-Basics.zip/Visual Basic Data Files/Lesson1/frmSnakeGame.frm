VERSION 5.00
Begin VB.Form frmMainForm 
   BackColor       =   &H00FFFFFF&
   Caption         =   "SNAKE GAME!!!!"
   ClientHeight    =   5205
   ClientLeft      =   2055
   ClientTop       =   2145
   ClientWidth     =   7785
   LinkTopic       =   "Form1"
   ScaleHeight     =   5205
   ScaleWidth      =   7785
   Begin VB.CommandButton cmdQuit 
      Cancel          =   -1  'True
      Caption         =   "Quit"
      Height          =   495
      Left            =   6480
      TabIndex        =   6
      Top             =   4560
      Width           =   1215
   End
   Begin VB.CommandButton cmdRight 
      Caption         =   "Right"
      Height          =   495
      Left            =   6960
      TabIndex        =   5
      Top             =   2880
      Width           =   735
   End
   Begin VB.CommandButton cmdLeft 
      Caption         =   "Left"
      Height          =   495
      Left            =   5520
      TabIndex        =   4
      Top             =   2880
      Width           =   735
   End
   Begin VB.CommandButton cmdDown 
      Caption         =   "Down"
      Height          =   495
      Left            =   6240
      TabIndex        =   3
      Top             =   3480
      Width           =   735
   End
   Begin VB.CommandButton cmdUp 
      Caption         =   "Up"
      Height          =   495
      Left            =   6240
      TabIndex        =   2
      Top             =   2280
      Width           =   735
   End
   Begin VB.CommandButton cmdStop 
      Caption         =   "Stop  Game"
      Height          =   495
      Left            =   4920
      TabIndex        =   1
      Top             =   4560
      Width           =   1215
   End
   Begin VB.CommandButton cmdStart 
      Caption         =   "Start Game"
      Default         =   -1  'True
      Height          =   495
      Left            =   3360
      TabIndex        =   0
      Top             =   4560
      Width           =   1215
   End
   Begin VB.Image imgSnakeLogo 
      Height          =   2070
      Left            =   1440
      Picture         =   "frmSnakeGame.frx":0000
      Top             =   1320
      Width           =   3045
   End
End
Attribute VB_Name = "frmMainForm"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Dim blnStop As Boolean   'Flag to stop game when user clicks the Stop Game button
Dim sngYFactor As Single
Dim sngXFactor As Single

Private Sub cmdStart_Click()

   Dim sngX As Single
   Dim sngY As Single
   Dim lngSnakeColor As Long
   Dim lngWasteTime As Long
   Dim lngMySpeed As Long
   Dim intI As Integer
   
   cmdStart.Enabled = False 'Disable Start Game button
   blnStop = False 'Set Stop flag to false
      
   lngSnakeColor = vbBlue
   lngMySpeed = 200000
   sngX = 100
   sngY = 100
   sngXFactor = 0
   sngYFactor = 1
   AutoRedraw = True
   ScaleMode = vbPixels
   imgSnakeLogo.Visible = False 'Make Snake Game logo invisible

   'Draw box
   Line (25, 25)-Step(330, 265), lngSnakeColor, B
   Line (27, 27)-Step(326, 260), vbWhite, BF

   'Event loop
   Do
     DoEvents 'Allows other programs to run
     For lngWasteTime = 0 To lngMySpeed
     Next lngWasteTime
     PSet (sngX, sngY), lngSnakeColor
     sngX = sngX + sngXFactor
     sngY = sngY + sngYFactor
   Loop Until ((Point(sngX, sngY) = lngSnakeColor) Or blnStop = True)
   
   If blnStop = False Then
    intI = MsgBox("GAME OVER!", vbExclamation, "Snake Game")
   Else
    intI = MsgBox("GAME STOPPED", vbExclamation, "Snake Game")
   End If
   
   cmdStart.Enabled = True

End Sub

Private Sub cmdQuit_Click()
    End
End Sub

Private Sub cmdStop_Click()
    blnStop = True
End Sub

Private Sub cmdUp_Click()
    sngYFactor = -1
    sngXFactor = 0
End Sub

Private Sub cmdDown_Click()
    sngYFactor = 1
    sngXFactor = 0
End Sub

Private Sub cmdLeft_Click()
    sngXFactor = -1
    sngYFactor = 0
End Sub

Private Sub cmdRight_Click()
    sngXFactor = 1
    sngYFactor = 0
End Sub
