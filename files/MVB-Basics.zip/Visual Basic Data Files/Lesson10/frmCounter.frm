VERSION 5.00
Begin VB.Form frmCounter 
   Caption         =   "Counter"
   ClientHeight    =   3195
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4680
   LinkTopic       =   "Form1"
   ScaleHeight     =   3195
   ScaleWidth      =   4680
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton cmdGo 
      Caption         =   "Go"
      Height          =   495
      Left            =   1800
      TabIndex        =   0
      Top             =   2280
      Width           =   1215
   End
   Begin VB.Label lblCounter 
      Caption         =   " "
      Height          =   495
      Left            =   1800
      TabIndex        =   1
      Top             =   960
      Width           =   1215
   End
End
Attribute VB_Name = "frmCounter"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdGo_Click()
 
    Dim lngCounter As Long  'Variable used for counter
    Dim intDelay As Integer 'Variable used to create delay

    cmdGo.Enabled = False 'Disable Go button
    lngCounter = 1 'Initialize counter
 
    'Begin outer loop
    Do While lngCounter <= 1000
        lblCounter.Caption = lngCounter 'Update label
        lngCounter = lngCounter + 1
        intDelay = 1
    Loop 'End of outer loop
 
    cmdGo.Enabled = True 'Enable Go button

End Sub
