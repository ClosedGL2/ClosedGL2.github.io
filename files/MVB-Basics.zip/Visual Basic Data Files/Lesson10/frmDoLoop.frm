VERSION 5.00
Begin VB.Form frmMain 
   Caption         =   "Do While Loop"
   ClientHeight    =   2340
   ClientLeft      =   2880
   ClientTop       =   1815
   ClientWidth     =   2475
   LinkTopic       =   "Form1"
   ScaleHeight     =   2340
   ScaleWidth      =   2475
   Begin VB.TextBox txtStart 
      Alignment       =   1  'Right Justify
      Height          =   285
      Left            =   600
      TabIndex        =   2
      Top             =   240
      Width           =   1215
   End
   Begin VB.CommandButton cmdCount 
      Caption         =   "Count"
      Height          =   495
      Left            =   600
      TabIndex        =   1
      Top             =   1560
      Width           =   1215
   End
   Begin VB.Label lblCounter 
      Alignment       =   2  'Center
      Caption         =   "0"
      Height          =   255
      Left            =   600
      TabIndex        =   0
      Top             =   840
      Visible         =   0   'False
      Width           =   1215
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdCount_Click()

End Sub

Private Sub txtStart_GotFocus()
    txtStart.SelStart = 0
    txtStart.SelLength = Len(txtStart.Text)
End Sub
