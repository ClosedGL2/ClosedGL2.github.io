VERSION 5.00
Begin VB.Form frmInputBox 
   Caption         =   "InputBox"
   ClientHeight    =   2145
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4680
   LinkTopic       =   "Form1"
   ScaleHeight     =   2145
   ScaleWidth      =   4680
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton cmdEnterName 
      Caption         =   "Enter Name"
      Height          =   495
      Left            =   1800
      TabIndex        =   0
      Top             =   1200
      Width           =   1215
   End
   Begin VB.Label lblName 
      Caption         =   " "
      Height          =   255
      Left            =   1920
      TabIndex        =   1
      Top             =   480
      Width           =   2535
   End
   Begin VB.Label lblYouEntered 
      Caption         =   "You entered the name:"
      Height          =   255
      Left            =   120
      TabIndex        =   2
      Top             =   480
      Width           =   1695
   End
End
Attribute VB_Name = "frmInputBox"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdEnterName_Click()

End Sub
