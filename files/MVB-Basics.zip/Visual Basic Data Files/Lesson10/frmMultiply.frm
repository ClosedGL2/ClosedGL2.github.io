VERSION 5.00
Begin VB.Form frmMultiply 
   Caption         =   "Multiply"
   ClientHeight    =   2505
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   3420
   LinkTopic       =   "Form1"
   ScaleHeight     =   2505
   ScaleWidth      =   3420
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton cmdNumber 
      Caption         =   "Enter Number"
      Height          =   495
      Left            =   960
      TabIndex        =   0
      Top             =   1560
      Width           =   1575
   End
   Begin VB.Label lblAnswer 
      Alignment       =   2  'Center
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   18
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   555
      Left            =   120
      TabIndex        =   1
      Top             =   480
      Width           =   3240
   End
End
Attribute VB_Name = "frmMultiply"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
