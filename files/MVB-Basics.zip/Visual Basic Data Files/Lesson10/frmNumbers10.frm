VERSION 5.00
Begin VB.Form frmMain 
   Caption         =   "Numbers"
   ClientHeight    =   2655
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   3420
   LinkTopic       =   "Form1"
   ScaleHeight     =   2655
   ScaleWidth      =   3420
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton cmdInput 
      Caption         =   "Input Numbers"
      Height          =   495
      Left            =   960
      TabIndex        =   0
      Top             =   1800
      Width           =   1335
   End
   Begin VB.Label lblAverage 
      AutoSize        =   -1  'True
      Caption         =   "Output for average of number"
      Height          =   195
      Left            =   240
      TabIndex        =   3
      Top             =   1080
      Visible         =   0   'False
      Width           =   2085
   End
   Begin VB.Label lblSum 
      AutoSize        =   -1  'True
      Caption         =   "Output for sum of numbers"
      Height          =   195
      Left            =   240
      TabIndex        =   2
      Top             =   720
      Visible         =   0   'False
      Width           =   1860
   End
   Begin VB.Label lblTotal 
      AutoSize        =   -1  'True
      Caption         =   "Output for total numbers entered"
      Height          =   195
      Left            =   240
      TabIndex        =   1
      Top             =   360
      Visible         =   0   'False
      Width           =   2280
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdInput_Click()

End Sub
