VERSION 5.00
Begin VB.Form frmForNext 
   Caption         =   "For Next Loops"
   ClientHeight    =   3195
   ClientLeft      =   1950
   ClientTop       =   2025
   ClientWidth     =   4410
   LinkTopic       =   "Form1"
   ScaleHeight     =   3195
   ScaleWidth      =   4410
   Begin VB.CommandButton cmdCountDown 
      Caption         =   "Count Down by Four"
      Height          =   495
      Left            =   2400
      TabIndex        =   1
      Top             =   2400
      Width           =   1695
   End
   Begin VB.CommandButton cmdCountByThree 
      Caption         =   "Count by Three"
      Height          =   495
      Left            =   240
      TabIndex        =   0
      Top             =   2400
      Width           =   1695
   End
End
Attribute VB_Name = "frmForNext"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
