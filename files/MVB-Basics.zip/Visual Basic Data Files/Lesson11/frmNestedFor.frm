VERSION 5.00
Begin VB.Form frmNestedFor 
   Caption         =   "Nested For Next Demonstration"
   ClientHeight    =   3195
   ClientLeft      =   1485
   ClientTop       =   1305
   ClientWidth     =   6240
   LinkTopic       =   "Form1"
   ScaleHeight     =   3195
   ScaleWidth      =   6240
   Begin VB.CommandButton cmdExit 
      Caption         =   "Exit"
      Height          =   495
      Left            =   4560
      TabIndex        =   2
      Top             =   2400
      Width           =   1215
   End
   Begin VB.CommandButton cmdClear 
      Caption         =   "Clear Window"
      Height          =   495
      Left            =   2520
      TabIndex        =   1
      Top             =   2400
      Width           =   1215
   End
   Begin VB.CommandButton cmdLoop 
      Caption         =   "Begin Loop"
      Height          =   495
      Left            =   480
      TabIndex        =   0
      Top             =   2400
      Width           =   1215
   End
End
Attribute VB_Name = "frmNestedFor"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdExit_Click()
  End
End Sub

Private Sub cmdClear_Click()
  Cls
End Sub
