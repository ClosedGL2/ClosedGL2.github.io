VERSION 5.00
Begin VB.Form frmPattern 
   Caption         =   "Pattern Demonstration"
   ClientHeight    =   2835
   ClientLeft      =   1005
   ClientTop       =   1305
   ClientWidth     =   6450
   LinkTopic       =   "Form1"
   ScaleHeight     =   2835
   ScaleWidth      =   6450
   Begin VB.CommandButton cmdClearWindow 
      Caption         =   "Clear Window"
      Height          =   495
      Left            =   3120
      TabIndex        =   9
      Top             =   1440
      Width           =   1215
   End
   Begin VB.CommandButton cmdAbout 
      Caption         =   "About..."
      Height          =   495
      Left            =   4800
      TabIndex        =   5
      Top             =   1440
      Width           =   1215
   End
   Begin VB.CommandButton cmdExit 
      Caption         =   "Exit"
      Height          =   495
      Left            =   4800
      TabIndex        =   4
      Top             =   2160
      Width           =   1215
   End
   Begin VB.CommandButton cmdCreatePattern 
      Caption         =   "Create Pattern"
      Height          =   495
      Left            =   3120
      TabIndex        =   3
      Top             =   2160
      Width           =   1215
   End
   Begin VB.TextBox txtC 
      Height          =   405
      Left            =   1920
      TabIndex        =   2
      Text            =   "1"
      Top             =   2280
      Width           =   615
   End
   Begin VB.TextBox txtB 
      Height          =   405
      Left            =   1920
      TabIndex        =   1
      Text            =   "1"
      Top             =   1800
      Width           =   615
   End
   Begin VB.TextBox txtA 
      Height          =   405
      Left            =   1920
      TabIndex        =   0
      Text            =   "1"
      Top             =   1320
      Width           =   615
   End
   Begin VB.Label lblUpperC 
      Alignment       =   1  'Right Justify
      Caption         =   "Upper limit for Loop C"
      Height          =   255
      Left            =   120
      TabIndex        =   8
      Top             =   2400
      Width           =   1695
   End
   Begin VB.Label lblUpperB 
      Alignment       =   1  'Right Justify
      Caption         =   "Upper limit for Loop B"
      Height          =   255
      Left            =   120
      TabIndex        =   7
      Top             =   1920
      Width           =   1695
   End
   Begin VB.Label lblUpperA 
      Alignment       =   1  'Right Justify
      Caption         =   "Upper limit for Loop A"
      Height          =   255
      Left            =   120
      TabIndex        =   6
      Top             =   1440
      Width           =   1695
   End
End
Attribute VB_Name = "frmPattern"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim intPatternCount As Integer

Private Sub cmdClearWindow_Click()
  intPatternCount = 0 'Reset pattern counter
  Cls ' Clear the window
  
  'Make sure the Create Pattern button is enabled
  cmdCreatePattern.Enabled = True
End Sub

Private Sub cmdCreatePattern_Click()
  'Declare variable used to store the upper limits
  'of the counting
  Dim intLimitA As Integer
  Dim intLimitB As Integer
  Dim intLimitC As Integer
  
  'Declare counter variables
  Dim intCounterA As Integer
  Dim intCounterB As Integer
  Dim intCounterC As Integer

  'Get values from text boxes
  intLimitA = Val(txtA.Text)
  intLimitB = Val(txtB.Text)
  intLimitC = Val(txtC.Text)
  
  'Increment counter to keep track of how many patterns
  'appear in window
  intPatternCount = intPatternCount + 1
  
  For intCounterA = 1 To intLimitA
    Print "A";
    For intCounterB = 1 To intLimitB
      Print "B";
      For intCounterC = 1 To intLimitC
        Print "C";
      Next intCounterC
    Next intCounterB
  Next intCounterA
  Print " "
  
  'If there are six patterns in the window, disable
  'the CreatePattern button until the Clear Window
  'button is clicked.
  If intPatternCount >= 6 Then
    cmdCreatePattern.Enabled = False
  End If
  
End Sub

Private Sub cmdExit_Click()
  End
End Sub

Private Sub txtA_GotFocus()
  txtA.SelStart = 0
  txtA.SelLength = Len(txtA.Text)
End Sub

Private Sub txtB_GotFocus()
  txtB.SelStart = 0
  txtB.SelLength = Len(txtB.Text)
End Sub

Private Sub txtC_GotFocus()
  txtC.SelStart = 0
  txtC.SelLength = Len(txtC.Text)
End Sub

