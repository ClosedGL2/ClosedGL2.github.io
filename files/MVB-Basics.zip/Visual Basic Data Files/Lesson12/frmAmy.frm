VERSION 5.00
Begin VB.Form frmAmy 
   BackColor       =   &H00FFFFFF&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Amy"
   ClientHeight    =   4245
   ClientLeft      =   1695
   ClientTop       =   1770
   ClientWidth     =   6090
   ControlBox      =   0   'False
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4245
   ScaleWidth      =   6090
   Begin VB.Image imgAmy 
      Height          =   3400
      Left            =   850
      Picture         =   "frmAmy.frx":0000
      Stretch         =   -1  'True
      Top             =   400
      Width           =   4400
   End
End
Attribute VB_Name = "frmAmy"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
