VERSION 5.00
Begin VB.Form frmMain 
   Caption         =   "Print Form"
   ClientHeight    =   2805
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4110
   LinkTopic       =   "Form1"
   ScaleHeight     =   2805
   ScaleWidth      =   4110
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton cmdPrint 
      Caption         =   "Print Form"
      Height          =   495
      Left            =   1440
      TabIndex        =   7
      Top             =   2160
      Width           =   1215
   End
   Begin VB.CommandButton cmdExit 
      Caption         =   "Exit"
      Height          =   495
      Left            =   2760
      TabIndex        =   8
      Top             =   2160
      Width           =   1215
   End
   Begin VB.CommandButton cmdCalculate 
      Caption         =   "Calculate"
      Height          =   495
      Left            =   120
      TabIndex        =   6
      Top             =   2160
      Width           =   1215
   End
   Begin VB.TextBox txtTotalSales 
      Height          =   285
      Left            =   2640
      TabIndex        =   5
      Text            =   " "
      Top             =   840
      Width           =   975
   End
   Begin VB.TextBox txtEmployee 
      Height          =   285
      Left            =   1800
      TabIndex        =   4
      Text            =   " "
      Top             =   360
      Width           =   1815
   End
   Begin VB.Label lblCommission 
      Caption         =   " "
      Height          =   255
      Left            =   2640
      TabIndex        =   3
      Top             =   1440
      Width           =   975
   End
   Begin VB.Label lblText1 
      AutoSize        =   -1  'True
      Caption         =   "Commission Earned"
      Height          =   195
      Left            =   360
      TabIndex        =   2
      Top             =   1440
      Width           =   1380
   End
   Begin VB.Label lblTotalSales 
      Caption         =   "Total Sales"
      Height          =   255
      Left            =   360
      TabIndex        =   1
      Top             =   840
      Width           =   1215
   End
   Begin VB.Label lblEmployee 
      Caption         =   "Employee"
      Height          =   255
      Left            =   360
      TabIndex        =   0
      Top             =   360
      Width           =   1215
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdCalculate_Click()
    Dim strAnswer As String
    Dim sngAnswer As Single
    
    'Calculate Commission
    sngAnswer = Val(txtTotalSales.Text) * 0.04
    
    'Display Results
    strAnswer = Format(sngAnswer, "$###,###.00")
    lblCommission.Caption = strAnswer
End Sub

Private Sub cmdExit_Click()
    End
End Sub

Private Sub cmdPrint_Click()

End Sub

Private Sub txtEmployee_GotFocus()
    txtEmployee.SelStart = 0
    txtEmployee.SelLength = Len(txtEmployee.Text)
End Sub

Private Sub txtTotalSales_GotFocus()
    txtTotalSales.SelStart = 0
    txtTotalSales.SelLength = Len(txtTotalSales.Text)
End Sub
