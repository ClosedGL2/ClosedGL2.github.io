VERSION 5.00
Begin VB.Form frmMain 
   Caption         =   "Print Name"
   ClientHeight    =   2355
   ClientLeft      =   165
   ClientTop       =   450
   ClientWidth     =   3525
   LinkTopic       =   "Form1"
   ScaleHeight     =   2355
   ScaleWidth      =   3525
   StartUpPosition =   3  'Windows Default
   Begin VB.TextBox txtName 
      Height          =   285
      Left            =   600
      TabIndex        =   1
      Top             =   840
      Width           =   2295
   End
   Begin VB.CommandButton cmdPrint 
      Caption         =   "Print Name to  Printer"
      Height          =   495
      Left            =   840
      TabIndex        =   0
      Top             =   1680
      Width           =   1815
   End
   Begin VB.Label lblName 
      Alignment       =   2  'Center
      Caption         =   "Enter your full name:"
      Height          =   255
      Left            =   120
      TabIndex        =   2
      Top             =   360
      Width           =   3255
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdPrint_Click()

End Sub
