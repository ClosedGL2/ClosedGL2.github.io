VERSION 5.00
Begin VB.Form frmGrowingCircle 
   Caption         =   "Growing Circle"
   ClientHeight    =   3195
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   5550
   LinkTopic       =   "Form1"
   ScaleHeight     =   3195
   ScaleWidth      =   5550
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton cmdExit 
      Caption         =   "Exit"
      Height          =   495
      Left            =   3840
      TabIndex        =   2
      Top             =   2280
      Width           =   1215
   End
   Begin VB.CommandButton cmdShrink 
      Caption         =   "Shrink"
      Height          =   495
      Left            =   3840
      TabIndex        =   1
      Top             =   840
      Width           =   1215
   End
   Begin VB.CommandButton cmdGrow 
      Caption         =   "Grow"
      Enabled         =   0   'False
      Height          =   495
      Left            =   3840
      TabIndex        =   0
      Top             =   120
      Width           =   1215
   End
   Begin VB.Shape shpCircle 
      Height          =   2775
      Left            =   120
      Shape           =   3  'Circle
      Top             =   120
      Width           =   3135
   End
End
Attribute VB_Name = "frmGrowingCircle"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdExit_Click()
  End
End Sub
