VERSION 5.00
Begin VB.Form frmMain 
   Caption         =   "Shape Draw"
   ClientHeight    =   3195
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4680
   LinkTopic       =   "Form1"
   ScaleHeight     =   3195
   ScaleWidth      =   4680
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton cmdExit 
      Caption         =   "Exit"
      Height          =   495
      Left            =   2760
      TabIndex        =   6
      Top             =   2520
      Width           =   1215
   End
   Begin VB.CommandButton cmdDraw 
      Caption         =   "Draw"
      Height          =   495
      Left            =   720
      TabIndex        =   5
      Top             =   2520
      Width           =   1215
   End
   Begin VB.Frame fraShape 
      Caption         =   "Shape"
      Height          =   2055
      Left            =   480
      TabIndex        =   0
      Top             =   240
      Width           =   1575
      Begin VB.OptionButton optSquare 
         Caption         =   "Square"
         Height          =   255
         Left            =   240
         TabIndex        =   4
         Top             =   1440
         Width           =   1095
      End
      Begin VB.OptionButton optRectangle 
         Caption         =   "Rectangle"
         Height          =   555
         Left            =   240
         TabIndex        =   3
         Top             =   960
         Width           =   1215
      End
      Begin VB.OptionButton optOval 
         Caption         =   "Oval"
         Height          =   375
         Left            =   240
         TabIndex        =   2
         Top             =   720
         Width           =   1095
      End
      Begin VB.OptionButton optCircle 
         Caption         =   "Circle"
         Height          =   375
         Left            =   240
         TabIndex        =   1
         Top             =   360
         Width           =   1215
      End
   End
   Begin VB.Shape shpMyShape 
      FillColor       =   &H00C00000&
      FillStyle       =   0  'Solid
      Height          =   1335
      Left            =   2520
      Shape           =   3  'Circle
      Top             =   600
      Visible         =   0   'False
      Width           =   1935
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdExit_Click()
  End
End Sub
