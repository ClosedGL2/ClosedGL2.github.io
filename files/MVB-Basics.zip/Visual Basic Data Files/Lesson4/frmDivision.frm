VERSION 5.00
Begin VB.Form frmdivision 
   Caption         =   "Division "
   ClientHeight    =   2160
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   2910
   LinkTopic       =   "Form1"
   ScaleHeight     =   2160
   ScaleWidth      =   2910
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton cmdExit 
      Caption         =   "Exit"
      Height          =   495
      Left            =   1560
      TabIndex        =   6
      Top             =   1440
      Width           =   1215
   End
   Begin VB.TextBox txtDivisor 
      Alignment       =   1  'Right Justify
      Height          =   285
      Left            =   120
      TabIndex        =   5
      Text            =   " "
      Top             =   720
      Width           =   855
   End
   Begin VB.TextBox txtDividend 
      Height          =   285
      Left            =   1200
      TabIndex        =   4
      Text            =   " "
      Top             =   720
      Width           =   1455
   End
   Begin VB.CommandButton cmdCalculate 
      Caption         =   "Calculate"
      Height          =   495
      Left            =   120
      TabIndex        =   2
      Top             =   1440
      Width           =   1215
   End
   Begin VB.Label lblRemainder 
      Caption         =   " "
      Height          =   195
      Left            =   2040
      TabIndex        =   3
      Top             =   360
      Width           =   615
   End
   Begin VB.Label lblr 
      AutoSize        =   -1  'True
      Caption         =   "r"
      Height          =   195
      Left            =   1875
      TabIndex        =   1
      Top             =   360
      Width           =   45
   End
   Begin VB.Label lblQuotient 
      Alignment       =   1  'Right Justify
      Caption         =   " "
      Height          =   195
      Left            =   1080
      TabIndex        =   0
      Top             =   360
      Width           =   615
   End
   Begin VB.Line Line2 
      X1              =   1080
      X2              =   1080
      Y1              =   1080
      Y2              =   600
   End
   Begin VB.Line Line1 
      X1              =   1080
      X2              =   2640
      Y1              =   600
      Y2              =   600
   End
End
Attribute VB_Name = "frmdivision"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdCalculate_Click()

End Sub

Private Sub cmdExit_Click()
    End
End Sub
