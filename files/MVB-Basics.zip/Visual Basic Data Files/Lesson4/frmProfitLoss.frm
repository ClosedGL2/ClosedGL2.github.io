VERSION 5.00
Begin VB.Form frmProfitLoss 
   Caption         =   "Profit & Loss"
   ClientHeight    =   4305
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   5220
   LinkTopic       =   "Form1"
   ScaleHeight     =   4305
   ScaleWidth      =   5220
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton cmdExit 
      Caption         =   "Exit"
      Height          =   495
      Left            =   3600
      TabIndex        =   25
      Top             =   3480
      Width           =   1215
   End
   Begin VB.CommandButton cmdCalculate 
      Caption         =   "Calculate"
      Height          =   495
      Left            =   3600
      TabIndex        =   17
      Top             =   2880
      Width           =   1215
   End
   Begin VB.TextBox txtOther 
      Height          =   285
      Left            =   1920
      TabIndex        =   15
      Text            =   " "
      Top             =   2520
      Width           =   1215
   End
   Begin VB.TextBox txtSupp 
      Height          =   285
      Left            =   1905
      TabIndex        =   14
      Text            =   " "
      Top             =   2160
      Width           =   1215
   End
   Begin VB.TextBox txtUtil 
      Height          =   285
      Left            =   1920
      TabIndex        =   13
      Text            =   " "
      Top             =   1800
      Width           =   1215
   End
   Begin VB.TextBox txtPayroll 
      Height          =   285
      Left            =   1905
      TabIndex        =   12
      Text            =   " "
      Top             =   1440
      Width           =   1215
   End
   Begin VB.TextBox txtRent 
      Height          =   285
      Left            =   1905
      TabIndex        =   11
      Text            =   " "
      Top             =   1080
      Width           =   1215
   End
   Begin VB.TextBox txtRev 
      Height          =   285
      Left            =   1905
      TabIndex        =   10
      Text            =   " "
      Top             =   240
      Width           =   1215
   End
   Begin VB.Label lblPercentages 
      AutoSize        =   -1  'True
      Caption         =   "Expense Percentages"
      Height          =   195
      Left            =   3360
      TabIndex        =   26
      Top             =   750
      Width           =   1560
   End
   Begin VB.Label lblTotalExp 
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   1  'Fixed Single
      Caption         =   " "
      Height          =   255
      Left            =   1920
      TabIndex        =   24
      Top             =   2880
      Width           =   1215
   End
   Begin VB.Label lblLoss 
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   1  'Fixed Single
      Caption         =   " "
      Height          =   255
      Left            =   1920
      TabIndex        =   23
      Top             =   3720
      Width           =   1215
   End
   Begin VB.Label lblProfit 
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   1  'Fixed Single
      Caption         =   " "
      Height          =   255
      Left            =   1920
      TabIndex        =   22
      Top             =   3360
      Width           =   1215
   End
   Begin VB.Label lblOtherPerc 
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   1  'Fixed Single
      Caption         =   " "
      Height          =   255
      Left            =   3600
      TabIndex        =   21
      Top             =   2520
      Width           =   1215
   End
   Begin VB.Label lblSuppPerc 
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   1  'Fixed Single
      Caption         =   " "
      Height          =   255
      Left            =   3600
      TabIndex        =   20
      Top             =   2160
      Width           =   1215
   End
   Begin VB.Label lblUtilPerc 
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   1  'Fixed Single
      Caption         =   " "
      Height          =   255
      Left            =   3600
      TabIndex        =   19
      Top             =   1800
      Width           =   1215
   End
   Begin VB.Label lblPayrollPerc 
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   1  'Fixed Single
      Caption         =   " "
      Height          =   255
      Left            =   3600
      TabIndex        =   18
      Top             =   1440
      Width           =   1215
   End
   Begin VB.Label lblRentPerc 
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   1  'Fixed Single
      Caption         =   " "
      Height          =   255
      Left            =   3600
      TabIndex        =   16
      Top             =   1110
      Width           =   1215
   End
   Begin VB.Label lblLossLabel 
      AutoSize        =   -1  'True
      Caption         =   "Loss"
      Height          =   195
      Left            =   360
      TabIndex        =   9
      Top             =   3750
      Width           =   330
   End
   Begin VB.Label lblProfitLabel 
      AutoSize        =   -1  'True
      Caption         =   "Profit"
      Height          =   195
      Left            =   360
      TabIndex        =   8
      Top             =   3390
      Width           =   360
   End
   Begin VB.Label lblTotalExpLabel 
      AutoSize        =   -1  'True
      Caption         =   "Total Expenses"
      Height          =   195
      Left            =   360
      TabIndex        =   7
      Top             =   2910
      Width           =   1095
   End
   Begin VB.Label lblOther 
      AutoSize        =   -1  'True
      Caption         =   "Other"
      Height          =   195
      Left            =   840
      TabIndex        =   6
      Top             =   2550
      Width           =   390
   End
   Begin VB.Label lblSupp 
      AutoSize        =   -1  'True
      Caption         =   "Supplies"
      Height          =   195
      Left            =   840
      TabIndex        =   5
      Top             =   2190
      Width           =   600
   End
   Begin VB.Label lblUtil 
      AutoSize        =   -1  'True
      Caption         =   "Utilities"
      Height          =   195
      Left            =   840
      TabIndex        =   4
      Top             =   1830
      Width           =   495
   End
   Begin VB.Label lblPayroll 
      AutoSize        =   -1  'True
      Caption         =   "Payroll"
      Height          =   195
      Left            =   840
      TabIndex        =   3
      Top             =   1470
      Width           =   465
   End
   Begin VB.Label lblRent 
      AutoSize        =   -1  'True
      Caption         =   "Rent"
      Height          =   195
      Left            =   840
      TabIndex        =   2
      Top             =   1110
      Width           =   345
   End
   Begin VB.Label lblExp 
      AutoSize        =   -1  'True
      Caption         =   "Expenses"
      Height          =   195
      Left            =   360
      TabIndex        =   1
      Top             =   750
      Width           =   690
   End
   Begin VB.Label lblRev 
      AutoSize        =   -1  'True
      Caption         =   "Revenue"
      Height          =   195
      Left            =   360
      TabIndex        =   0
      Top             =   240
      Width           =   660
   End
End
Attribute VB_Name = "frmProfitLoss"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdCalculate_Click()
End Sub

Private Sub cmdExit_Click()
    End
End Sub
