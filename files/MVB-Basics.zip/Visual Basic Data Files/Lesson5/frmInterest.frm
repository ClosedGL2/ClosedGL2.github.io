VERSION 5.00
Begin VB.Form frmInterest 
   Caption         =   "Interest Calculation"
   ClientHeight    =   2790
   ClientLeft      =   2175
   ClientTop       =   1560
   ClientWidth     =   4035
   LinkTopic       =   "Form1"
   ScaleHeight     =   2790
   ScaleWidth      =   4035
   Begin VB.CommandButton cmdExit 
      Caption         =   "Exit"
      Height          =   495
      Left            =   2520
      TabIndex        =   11
      Top             =   2040
      Width           =   1215
   End
   Begin VB.CommandButton cmdCalculate 
      Caption         =   "Calculate"
      Height          =   495
      Left            =   360
      TabIndex        =   10
      Top             =   2040
      Width           =   1215
   End
   Begin VB.TextBox txtYears 
      Alignment       =   1  'Right Justify
      Height          =   285
      Left            =   2400
      TabIndex        =   9
      Text            =   " "
      Top             =   960
      Width           =   1215
   End
   Begin VB.TextBox txtInterest 
      Alignment       =   1  'Right Justify
      Height          =   285
      Left            =   2400
      TabIndex        =   8
      Text            =   " "
      Top             =   600
      Width           =   1215
   End
   Begin VB.TextBox txtDeposit 
      Alignment       =   1  'Right Justify
      Height          =   285
      Left            =   2400
      TabIndex        =   7
      Text            =   " "
      Top             =   240
      Width           =   1215
   End
   Begin VB.Label lblTotal 
      AutoSize        =   -1  'True
      Caption         =   " "
      Height          =   195
      Left            =   3120
      TabIndex        =   6
      Top             =   1440
      Width           =   45
   End
   Begin VB.Label lblYearsSaved 
      Alignment       =   2  'Center
      AutoSize        =   -1  'True
      Caption         =   " "
      Height          =   195
      Left            =   2190
      TabIndex        =   5
      Top             =   1440
      Width           =   75
   End
   Begin VB.Label lblLabel2 
      AutoSize        =   -1  'True
      Caption         =   "years is $"
      Height          =   195
      Left            =   2400
      TabIndex        =   4
      Top             =   1440
      Width           =   660
   End
   Begin VB.Label lblLabel1 
      AutoSize        =   -1  'True
      Caption         =   "Amount in savings after "
      Height          =   195
      Left            =   360
      TabIndex        =   3
      Top             =   1440
      Width           =   1695
   End
   Begin VB.Label lblYears 
      AutoSize        =   -1  'True
      Caption         =   "Number of Years Saved"
      Height          =   195
      Left            =   360
      TabIndex        =   2
      Top             =   960
      Width           =   1695
   End
   Begin VB.Label lblInterestRate 
      AutoSize        =   -1  'True
      Caption         =   "Interest Rate in %"
      Height          =   195
      Left            =   360
      TabIndex        =   1
      Top             =   600
      Width           =   1245
   End
   Begin VB.Label lblDeposit 
      AutoSize        =   -1  'True
      Caption         =   "Amount Deposited"
      Height          =   195
      Left            =   360
      TabIndex        =   0
      Top             =   240
      Width           =   1305
   End
End
Attribute VB_Name = "frmInterest"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdCalculate_Click()

End Sub

Private Sub cmdExit_Click()
    End
End Sub
