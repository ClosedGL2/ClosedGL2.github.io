VERSION 5.00
Begin VB.Form frmTrain 
   Caption         =   "Train Information"
   ClientHeight    =   3195
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4830
   LinkTopic       =   "Form1"
   ScaleHeight     =   3195
   ScaleWidth      =   4830
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton cmdHopper 
      Caption         =   "Hopper Car"
      Height          =   495
      Left            =   2640
      TabIndex        =   7
      Top             =   1800
      Width           =   1215
   End
   Begin VB.CommandButton cmdTank 
      Caption         =   "Tank Car"
      Height          =   495
      Left            =   1080
      TabIndex        =   6
      Top             =   1800
      Width           =   1215
   End
   Begin VB.CommandButton cmdExit 
      Caption         =   "Exit"
      Height          =   495
      Left            =   3360
      TabIndex        =   3
      Top             =   240
      Width           =   1215
   End
   Begin VB.CommandButton cmdRefrig 
      Caption         =   "Refrigerated Car"
      Height          =   495
      Left            =   3360
      TabIndex        =   2
      Top             =   2400
      Width           =   1215
   End
   Begin VB.CommandButton cmdCaboose 
      Caption         =   "Caboose"
      Height          =   495
      Left            =   1800
      TabIndex        =   1
      Top             =   2400
      Width           =   1215
   End
   Begin VB.CommandButton cmdBox 
      Caption         =   "Box Car"
      Height          =   495
      Left            =   240
      TabIndex        =   0
      Top             =   2400
      Width           =   1215
   End
   Begin VB.Label lblWeight 
      AutoSize        =   -1  'True
      Caption         =   "0"
      Height          =   195
      Left            =   2040
      TabIndex        =   9
      Top             =   960
      Width           =   90
   End
   Begin VB.Label lblNumber 
      AutoSize        =   -1  'True
      Caption         =   "0"
      Height          =   195
      Left            =   2040
      TabIndex        =   8
      Top             =   600
      Width           =   90
   End
   Begin VB.Label Label2 
      AutoSize        =   -1  'True
      Caption         =   "Total Weight of Train"
      Height          =   195
      Left            =   120
      TabIndex        =   5
      Top             =   960
      Width           =   1500
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      Caption         =   "Number of Cars on Train"
      Height          =   195
      Left            =   120
      TabIndex        =   4
      Top             =   600
      Width           =   1725
   End
End
Attribute VB_Name = "frmTrain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
