VERSION 5.00
Begin VB.Form frmDogYears 
   Caption         =   "Dog Years Converter"
   ClientHeight    =   3825
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4875
   LinkTopic       =   "Form1"
   ScaleHeight     =   3825
   ScaleWidth      =   4875
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton cmdExit 
      Caption         =   "Exit"
      Height          =   495
      Left            =   3000
      TabIndex        =   9
      Top             =   3120
      Width           =   1215
   End
   Begin VB.TextBox txtMonths 
      Height          =   285
      Left            =   2640
      TabIndex        =   6
      Text            =   "0"
      Top             =   560
      Width           =   1215
   End
   Begin VB.TextBox txtYears 
      Height          =   285
      Left            =   2640
      TabIndex        =   5
      Text            =   "0"
      Top             =   200
      Width           =   1215
   End
   Begin VB.CommandButton cmdDog 
      Caption         =   "Dog"
      Height          =   495
      Left            =   600
      TabIndex        =   4
      Top             =   3120
      Width           =   1215
   End
   Begin VB.CommandButton cmdMonths 
      Caption         =   "Calculate age in months."
      Height          =   495
      Left            =   1200
      TabIndex        =   3
      Top             =   1560
      Width           =   2295
   End
   Begin VB.Label lblInstructions 
      AutoSize        =   -1  'True
      Caption         =   "Click the Dog button to estimate your age in dog years."
      Height          =   195
      Left            =   600
      TabIndex        =   8
      Top             =   2400
      Visible         =   0   'False
      Width           =   3870
   End
   Begin VB.Label lblOutputAnimalYears 
      Alignment       =   2  'Center
      AutoSize        =   -1  'True
      Caption         =   "Output for the Number of Animal Years"
      Height          =   195
      Left            =   120
      TabIndex        =   7
      Top             =   2640
      Visible         =   0   'False
      Width           =   4665
   End
   Begin VB.Label lblOutputMonths 
      Alignment       =   2  'Center
      Caption         =   "Output for Number of Months"
      Height          =   195
      Left            =   120
      TabIndex        =   2
      Top             =   1080
      Visible         =   0   'False
      Width           =   4575
   End
   Begin VB.Label lblMonths 
      AutoSize        =   -1  'True
      Caption         =   "Months since last birthday:"
      Height          =   195
      Left            =   360
      TabIndex        =   1
      Top             =   600
      Width           =   1875
   End
   Begin VB.Label lblAge 
      AutoSize        =   -1  'True
      Caption         =   "Age in years:"
      Height          =   195
      Left            =   360
      TabIndex        =   0
      Top             =   240
      Width           =   915
   End
End
Attribute VB_Name = "frmDogYears"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim intMonths As Integer

Private Sub cmdExit_Click()
    End
End Sub

Private Sub cmdMonths_Click()
    'Calculate Months
    intMonths = (Val(txtYears.Text) * 12) + Val(txtMonths.Text)
End Sub


