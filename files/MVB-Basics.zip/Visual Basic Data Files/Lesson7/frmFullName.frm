VERSION 5.00
Begin VB.Form frmName 
   Caption         =   "Full Name"
   ClientHeight    =   3990
   ClientLeft      =   3720
   ClientTop       =   2595
   ClientWidth     =   4680
   LinkTopic       =   "Form1"
   ScaleHeight     =   3990
   ScaleWidth      =   4680
   Begin VB.CommandButton cmdExit 
      Cancel          =   -1  'True
      Caption         =   "Exit"
      Height          =   495
      Left            =   2400
      TabIndex        =   9
      Top             =   2400
      Width           =   1215
   End
   Begin VB.CommandButton cmdOk 
      Caption         =   "OK"
      Default         =   -1  'True
      Height          =   495
      Left            =   960
      TabIndex        =   3
      Top             =   2400
      Width           =   1215
   End
   Begin VB.TextBox txtLastName 
      Height          =   375
      Left            =   1920
      TabIndex        =   2
      Top             =   1680
      Width           =   2415
   End
   Begin VB.TextBox txtMiddleName 
      Height          =   375
      Left            =   1920
      TabIndex        =   1
      Top             =   1080
      Width           =   2415
   End
   Begin VB.TextBox txtFirstName 
      Height          =   375
      Left            =   1920
      TabIndex        =   0
      Top             =   480
      Width           =   2415
   End
   Begin VB.Label lblFullName 
      AutoSize        =   -1  'True
      Caption         =   "         "
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   300
      Left            =   960
      TabIndex        =   8
      Top             =   3480
      Visible         =   0   'False
      Width           =   690
   End
   Begin VB.Label lblFullNamePrompt 
      AutoSize        =   -1  'True
      Caption         =   "Your full name is: "
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   300
      Left            =   240
      TabIndex        =   7
      Top             =   3120
      Width           =   1875
   End
   Begin VB.Label lblLastNamePrompt 
      AutoSize        =   -1  'True
      Caption         =   "Last Name:"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   300
      Left            =   240
      TabIndex        =   6
      Top             =   1680
      Width           =   1380
   End
   Begin VB.Label Label1lblMiddleNamePrompt 
      AutoSize        =   -1  'True
      Caption         =   "Middle Name:"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   300
      Left            =   240
      TabIndex        =   5
      Top             =   1080
      Width           =   1635
   End
   Begin VB.Label lblFirstNamePrompt 
      AutoSize        =   -1  'True
      Caption         =   "First Name: "
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   300
      Left            =   240
      TabIndex        =   4
      Top             =   480
      Width           =   1470
   End
End
Attribute VB_Name = "frmName"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdExit_Click()
    End
End Sub

