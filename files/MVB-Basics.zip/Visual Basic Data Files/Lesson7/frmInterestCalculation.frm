VERSION 5.00
Begin VB.Form frmInterest 
   Caption         =   "Interest Calculation"
   ClientHeight    =   2790
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4035
   LinkTopic       =   "Form1"
   ScaleHeight     =   2790
   ScaleWidth      =   4035
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton cmdExit 
      Caption         =   "Exit"
      Height          =   495
      Left            =   2520
      TabIndex        =   8
      Top             =   2040
      Width           =   1215
   End
   Begin VB.CommandButton cmdCalculate 
      Caption         =   "Calculate"
      Height          =   495
      Left            =   360
      TabIndex        =   7
      Top             =   2040
      Width           =   1215
   End
   Begin VB.TextBox txtYears 
      Alignment       =   1  'Right Justify
      Height          =   285
      Left            =   2400
      TabIndex        =   6
      Text            =   " "
      Top             =   960
      Width           =   1215
   End
   Begin VB.TextBox txtInterest 
      Alignment       =   1  'Right Justify
      Height          =   285
      Left            =   2400
      TabIndex        =   5
      Text            =   " "
      Top             =   600
      Width           =   1215
   End
   Begin VB.TextBox txtDeposit 
      Alignment       =   1  'Right Justify
      Height          =   285
      Left            =   2400
      TabIndex        =   4
      Text            =   " "
      Top             =   240
      Width           =   1215
   End
   Begin VB.Label lblOutput 
      AutoSize        =   -1  'True
      Caption         =   "Output"
      Height          =   195
      Left            =   360
      TabIndex        =   3
      Top             =   1440
      Visible         =   0   'False
      Width           =   480
   End
   Begin VB.Label lblYears 
      AutoSize        =   -1  'True
      Caption         =   "Number of Years Saved"
      Height          =   195
      Left            =   360
      TabIndex        =   2
      Top             =   960
      Width           =   1695
   End
   Begin VB.Label lblInterestRate 
      AutoSize        =   -1  'True
      Caption         =   "Interest Rate in %"
      Height          =   195
      Left            =   360
      TabIndex        =   1
      Top             =   600
      Width           =   1245
   End
   Begin VB.Label lblDeposit 
      AutoSize        =   -1  'True
      Caption         =   "Amount Deposited"
      Height          =   195
      Left            =   360
      TabIndex        =   0
      Top             =   240
      Width           =   1305
   End
End
Attribute VB_Name = "frmInterest"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdCalculate_Click()
    'If error occurs, go to end of the routine to print error message
    On Error GoTo ErrorHandler
    
    'Calculate future value
    lblTotal.Caption = Fix(txtDeposit.Text * _
    (1 + (txtInterest.Text / 100)) ^ txtYears.Text)
    
    'End procedure
    Exit Sub

'Error Handler
ErrorHandler:
    MsgBox ("The values you entered resulted in an error. Try Again.")
    Exit Sub
End Sub

Private Sub cmdExit_Click()
    End
End Sub
