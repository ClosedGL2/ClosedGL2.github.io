VERSION 5.00
Begin VB.Form frmLibrary 
   Caption         =   "Library Fines"
   ClientHeight    =   3435
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   3615
   LinkTopic       =   "Form1"
   ScaleHeight     =   3435
   ScaleWidth      =   3615
   StartUpPosition =   3  'Windows Default
   Begin VB.TextBox txtWeeks 
      Height          =   285
      Left            =   2040
      TabIndex        =   3
      Text            =   " "
      Top             =   1680
      Width           =   1215
   End
   Begin VB.CommandButton cmdExit 
      Caption         =   "Exit"
      Height          =   495
      Left            =   2040
      TabIndex        =   5
      Top             =   2760
      Width           =   1215
   End
   Begin VB.CommandButton cmdCalculate 
      Caption         =   "Calculate Late Fee"
      Height          =   495
      Left            =   360
      TabIndex        =   4
      Top             =   2760
      Width           =   1215
   End
   Begin VB.TextBox txtBooks 
      Height          =   285
      Left            =   2040
      TabIndex        =   2
      Text            =   " "
      Top             =   1200
      Width           =   1215
   End
   Begin VB.TextBox txtLast 
      Height          =   285
      Left            =   2040
      TabIndex        =   1
      Text            =   " "
      Top             =   720
      Width           =   1215
   End
   Begin VB.TextBox txtFirst 
      Height          =   285
      Left            =   2040
      TabIndex        =   0
      Text            =   " "
      Top             =   240
      Width           =   1215
   End
   Begin VB.Label lblText4 
      Alignment       =   1  'Right Justify
      AutoSize        =   -1  'True
      Caption         =   "Weeks Late:"
      Height          =   195
      Left            =   840
      TabIndex        =   10
      Top             =   1725
      Width           =   915
   End
   Begin VB.Label lblOutput 
      Alignment       =   2  'Center
      Caption         =   "Output"
      Height          =   195
      Left            =   120
      TabIndex        =   9
      Top             =   2160
      Visible         =   0   'False
      Width           =   3360
   End
   Begin VB.Label lblText3 
      Alignment       =   1  'Right Justify
      AutoSize        =   -1  'True
      Caption         =   "Books Due:"
      Height          =   195
      Left            =   840
      TabIndex        =   8
      Top             =   1245
      Width           =   840
   End
   Begin VB.Label lblText1 
      Alignment       =   1  'Right Justify
      AutoSize        =   -1  'True
      Caption         =   "First Name:"
      Height          =   195
      Left            =   840
      TabIndex        =   7
      Top             =   270
      Width           =   795
   End
   Begin VB.Label lblText2 
      Alignment       =   1  'Right Justify
      AutoSize        =   -1  'True
      Caption         =   "Last Name:"
      Height          =   195
      Left            =   840
      TabIndex        =   6
      Top             =   750
      Width           =   810
   End
End
Attribute VB_Name = "frmLibrary"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdCalculate_Click()

End Sub

Private Sub cmdExit_Click()
    End
End Sub
