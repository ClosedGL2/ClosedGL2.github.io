VERSION 5.00
Begin VB.Form frmCopy 
   Caption         =   "Copy Strings"
   ClientHeight    =   1845
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   3750
   LinkTopic       =   "Form1"
   ScaleHeight     =   1845
   ScaleWidth      =   3750
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton cmdReset 
      Caption         =   "Reset Text Box 1"
      Height          =   495
      Left            =   240
      TabIndex        =   3
      Top             =   1080
      Width           =   1455
   End
   Begin VB.CommandButton cmdCopy 
      Caption         =   "Copy Text"
      Height          =   495
      Left            =   2040
      TabIndex        =   2
      Top             =   1080
      Width           =   1455
   End
   Begin VB.TextBox txtText2 
      Height          =   285
      Left            =   2040
      TabIndex        =   1
      Text            =   " "
      Top             =   480
      Width           =   1455
   End
   Begin VB.TextBox txtText1 
      Height          =   285
      Left            =   240
      TabIndex        =   0
      Text            =   " "
      Top             =   480
      Width           =   1455
   End
   Begin VB.Label lblTextBox2 
      Caption         =   "Text Box 2"
      Height          =   255
      Left            =   2040
      TabIndex        =   5
      Top             =   240
      Width           =   855
   End
   Begin VB.Label lblTextBox1 
      Caption         =   "Text Box 1"
      Height          =   255
      Left            =   240
      TabIndex        =   4
      Top             =   240
      Width           =   855
   End
End
Attribute VB_Name = "frmCopy"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub Form_Load()

End Sub
