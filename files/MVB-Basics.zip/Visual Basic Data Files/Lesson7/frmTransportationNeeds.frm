VERSION 5.00
Begin VB.Form frmTransportationNeeds 
   Caption         =   "Transportation Needs"
   ClientHeight    =   3195
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   3945
   LinkTopic       =   "Form1"
   ScaleHeight     =   3195
   ScaleWidth      =   3945
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton cmdExit 
      Caption         =   "Exit"
      Height          =   495
      Left            =   2280
      TabIndex        =   7
      Top             =   2520
      Width           =   1215
   End
   Begin VB.CommandButton cmdCalculate 
      Caption         =   "Calculate"
      Height          =   495
      Left            =   360
      TabIndex        =   6
      Top             =   2520
      Width           =   1215
   End
   Begin VB.TextBox txtPeoplePerBus 
      Height          =   285
      Left            =   2160
      TabIndex        =   1
      Text            =   "0"
      Top             =   960
      Width           =   1215
   End
   Begin VB.TextBox txtPeople 
      Height          =   285
      Left            =   2160
      TabIndex        =   0
      Text            =   "0"
      Top             =   480
      Width           =   1215
   End
   Begin VB.Label lblExtra 
      Caption         =   " "
      Height          =   255
      Left            =   2160
      TabIndex        =   9
      Top             =   1800
      Visible         =   0   'False
      Width           =   1215
   End
   Begin VB.Label lblLabel2 
      AutoSize        =   -1  'True
      Caption         =   "Left over people:"
      Height          =   195
      Left            =   870
      TabIndex        =   8
      Top             =   1800
      Visible         =   0   'False
      Width           =   1200
   End
   Begin VB.Label lblBusesNeeded 
      Caption         =   " "
      Height          =   255
      Left            =   2160
      TabIndex        =   5
      Top             =   1560
      Visible         =   0   'False
      Width           =   1215
   End
   Begin VB.Label lblLabel1 
      AutoSize        =   -1  'True
      Caption         =   "Number of buses needed:"
      Height          =   195
      Left            =   240
      TabIndex        =   4
      Top             =   1560
      Visible         =   0   'False
      Width           =   1830
   End
   Begin VB.Label lblBuses 
      AutoSize        =   -1  'True
      Caption         =   "People per Bus"
      Height          =   195
      Left            =   480
      TabIndex        =   3
      Top             =   960
      Width           =   1080
   End
   Begin VB.Label lblPeople 
      AutoSize        =   -1  'True
      Caption         =   "Number of people"
      Height          =   195
      Left            =   480
      TabIndex        =   2
      Top             =   480
      Width           =   1260
   End
End
Attribute VB_Name = "frmTransportationNeeds"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdCalculate_Click()
    'Calculate buses needed
    lblBusesNeeded.Caption = Val(txtPeople.Text) \ Val(txtPeoplePerBus.Text)
    
    'Calculate extra people
    lblExtra.Caption = Val(txtPeople.Text) Mod Val(txtPeoplePerBus.Text)
    
    'Display results
    lblLabel1.Visible = True
    lblLabel2.Visible = True
    lblBusesNeeded.Visible = True
    lblExtra.Visible = True
End Sub

Private Sub cmdExit_Click()
    End
End Sub
