VERSION 5.00
Begin VB.Form frmCoaster 
   Caption         =   "Rollercoaster"
   ClientHeight    =   3195
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   3360
   LinkTopic       =   "Form1"
   ScaleHeight     =   3195
   ScaleWidth      =   3360
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton cmdExit 
      Caption         =   "Exit"
      Height          =   495
      Left            =   1800
      TabIndex        =   4
      Top             =   2520
      Width           =   1215
   End
   Begin VB.CommandButton cmdOk 
      Caption         =   "OK"
      Height          =   495
      Left            =   240
      TabIndex        =   3
      Top             =   2520
      Width           =   1215
   End
   Begin VB.TextBox txtHeight 
      Alignment       =   1  'Right Justify
      Height          =   285
      Left            =   1560
      TabIndex        =   0
      Text            =   "0"
      Top             =   360
      Width           =   615
   End
   Begin VB.Label lblResult 
      Alignment       =   2  'Center
      Caption         =   " "
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   18
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   240
      TabIndex        =   2
      Top             =   1800
      Width           =   2775
   End
   Begin VB.Label lblText1 
      AutoSize        =   -1  'True
      Caption         =   "Height in inches:"
      Height          =   195
      Left            =   240
      TabIndex        =   1
      Top             =   360
      Width           =   1185
   End
End
Attribute VB_Name = "frmCoaster"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdExit_Click()
    End
End Sub

Private Sub txtHeight_GotFocus()
    txtHeight.SelStart = 0
    txtHeight.SelLength = Len(txtHeight.Text)
End Sub
