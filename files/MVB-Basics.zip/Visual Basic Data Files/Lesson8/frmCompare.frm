VERSION 5.00
Begin VB.Form frmMainForm 
   Caption         =   "Compare"
   ClientHeight    =   2610
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   3555
   LinkTopic       =   "Form1"
   ScaleHeight     =   2610
   ScaleWidth      =   3555
   StartUpPosition =   3  'Windows Default
   Begin VB.TextBox txtRight 
      Height          =   375
      Left            =   2040
      TabIndex        =   3
      Text            =   "0"
      Top             =   480
      Width           =   975
   End
   Begin VB.TextBox txtLeft 
      Height          =   375
      Left            =   480
      TabIndex        =   2
      Text            =   "0"
      Top             =   480
      Width           =   975
   End
   Begin VB.CommandButton cmdCompare 
      Caption         =   "Compare"
      Height          =   495
      Left            =   1080
      TabIndex        =   1
      Top             =   1920
      Width           =   1335
   End
   Begin VB.Label lblLabel1 
      AutoSize        =   -1  'True
      Caption         =   "="
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   300
      Left            =   1680
      TabIndex        =   4
      Top             =   480
      Width           =   135
   End
   Begin VB.Label lblOutput 
      Caption         =   " "
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   13.5
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   1200
      TabIndex        =   0
      Top             =   1200
      Width           =   1095
   End
End
Attribute VB_Name = "frmMainForm"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub txtLeft_GotFocus()
    txtLeft.SelStart = 0
    txtLeft.SelLength = Len(txtLeft.Text)
End Sub

Private Sub txtRight_GotFocus()
    txtRight.SelStart = 0
    txtRight.SelLength = Len(txtRight.Text)
End Sub
