VERSION 5.00
Begin VB.Form frmMainForm 
   Caption         =   "Negative or Positive?"
   ClientHeight    =   3045
   ClientLeft      =   2175
   ClientTop       =   1725
   ClientWidth     =   3345
   LinkTopic       =   "Form1"
   ScaleHeight     =   3045
   ScaleWidth      =   3345
   Begin VB.CommandButton cmdExit 
      Caption         =   "Exit"
      Height          =   495
      Left            =   1800
      TabIndex        =   4
      Top             =   2280
      Width           =   1215
   End
   Begin VB.CommandButton cmdOk 
      Caption         =   "OK"
      Height          =   495
      Left            =   360
      TabIndex        =   1
      Top             =   2280
      Width           =   1215
   End
   Begin VB.TextBox txtNumber 
      Alignment       =   1  'Right Justify
      Height          =   285
      Left            =   1200
      TabIndex        =   0
      Text            =   "0"
      Top             =   1080
      Width           =   975
   End
   Begin VB.Label lblResult 
      Alignment       =   2  'Center
      Caption         =   " "
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   120
      TabIndex        =   3
      Top             =   1560
      Width           =   3135
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Caption         =   "Enter a number and click OK to determine whether the number is positive or negative."
      Height          =   615
      Left            =   360
      TabIndex        =   2
      Top             =   120
      Width           =   2535
   End
End
Attribute VB_Name = "frmMainForm"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdExit_Click()
    End
End Sub

Private Sub txtNumber_GotFocus()
    txtNumber.SelStart = 0
    txtNumber.SelLength = Len(txtNumber.Text)
End Sub
