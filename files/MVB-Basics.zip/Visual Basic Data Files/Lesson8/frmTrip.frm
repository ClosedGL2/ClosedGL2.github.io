VERSION 5.00
Begin VB.Form fmrMain 
   Caption         =   "Spring Break Trip"
   ClientHeight    =   3615
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   3615
   LinkTopic       =   "Form1"
   ScaleHeight     =   3615
   ScaleWidth      =   3615
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton cmdExit 
      Caption         =   "Exit"
      Height          =   495
      Left            =   2160
      TabIndex        =   1
      Top             =   3000
      Width           =   1215
   End
   Begin VB.CommandButton cmdCalc 
      Caption         =   "Calculate"
      Height          =   495
      Left            =   240
      TabIndex        =   0
      Top             =   3000
      Width           =   1215
   End
   Begin VB.Label lblText1 
      Caption         =   "Choose additional items for school trip."
      Height          =   255
      Left            =   360
      TabIndex        =   3
      Top             =   240
      Width           =   2775
   End
   Begin VB.Label lblOutput 
      Alignment       =   2  'Center
      Height          =   255
      Left            =   240
      TabIndex        =   2
      Top             =   2400
      Width           =   3255
   End
End
Attribute VB_Name = "fmrMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdExit_Click()
    End
End Sub
