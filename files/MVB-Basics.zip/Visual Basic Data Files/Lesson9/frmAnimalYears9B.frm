VERSION 5.00
Begin VB.Form frmAnimalYears 
   Caption         =   "Animal Years Converter"
   ClientHeight    =   5535
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4875
   LinkTopic       =   "Form1"
   ScaleHeight     =   5535
   ScaleWidth      =   4875
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton cmdExit 
      Caption         =   "Exit"
      Height          =   495
      Left            =   3000
      TabIndex        =   8
      Top             =   4800
      Width           =   1215
   End
   Begin VB.TextBox txtMonths 
      Height          =   285
      Left            =   2640
      TabIndex        =   6
      Text            =   "0"
      Top             =   560
      Width           =   1215
   End
   Begin VB.TextBox txtYears 
      Height          =   285
      Left            =   2640
      TabIndex        =   5
      Text            =   "0"
      Top             =   200
      Width           =   1215
   End
   Begin VB.CommandButton cmdCalc 
      Caption         =   "Calculate"
      Enabled         =   0   'False
      Height          =   495
      Left            =   720
      TabIndex        =   4
      Top             =   4800
      Width           =   1215
   End
   Begin VB.CommandButton cmdMonths 
      Caption         =   "Calculate age in months."
      Height          =   495
      Left            =   1200
      TabIndex        =   3
      Top             =   1560
      Width           =   2295
   End
   Begin VB.Label lblOutputAnimalYears 
      Alignment       =   2  'Center
      AutoSize        =   -1  'True
      Caption         =   "Output for the Number of Animal Years"
      Height          =   195
      Left            =   120
      TabIndex        =   7
      Top             =   2400
      Visible         =   0   'False
      Width           =   4665
   End
   Begin VB.Label lblOutputMonths 
      Alignment       =   2  'Center
      Caption         =   "Output for Number of Months"
      Height          =   195
      Left            =   120
      TabIndex        =   2
      Top             =   1080
      Visible         =   0   'False
      Width           =   4575
   End
   Begin VB.Label lblMonths 
      AutoSize        =   -1  'True
      Caption         =   "Months since last birthday:"
      Height          =   195
      Left            =   360
      TabIndex        =   1
      Top             =   600
      Width           =   1875
   End
   Begin VB.Label lblAge 
      AutoSize        =   -1  'True
      Caption         =   "Age in years:"
      Height          =   195
      Left            =   360
      TabIndex        =   0
      Top             =   240
      Width           =   915
   End
End
Attribute VB_Name = "frmAnimalYears"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim intMonths As Integer

Private Sub cmdCalc_Click()

End Sub

Private Sub cmdExit_Click()
    End
End Sub

Private Sub cmdMonths_Click()
    'Calculate Months
    intMonths = (Val(txtYears.Text) * 12) + Val(txtMonths.Text)
    
    'Display Number of Months Old
    lblOutputMonths.Caption = "You are " & intMonths & " months old."
    lblOutputMonths.Visible = True
    
    cmdCalc.Enabled = True
    
End Sub

Private Sub txtMonths_Change()
    'Enable Human Months Button
    cmdMonths.Enabled = True
    
    'Hide output
    lblOutputAnimalYears.Visible = False
    cmdCalc.Enabled = False
End Sub

Private Sub txtMonths_GotFocus()
    'Select Text
    txtMonths.SelStart = 0
    txtMonths.SelLength = Len(txtYears.Text)
End Sub

Private Sub txtYears_Change()
    'Enable Human Months Button
    cmdMonths.Enabled = True
    
    'Hide Output
    lblOutputAnimalYears.Visible = False
    cmdCalc.Enabled = False
End Sub

Private Sub txtYears_GotFocus()
    'Select Text
    txtYears.SelStart = 0
    txtYears.SelLength = Len(txtYears.Text)
End Sub
