VERSION 5.00
Begin VB.Form frmMain 
   Caption         =   "Checking Accounts"
   ClientHeight    =   3120
   ClientLeft      =   1710
   ClientTop       =   1500
   ClientWidth     =   3165
   LinkTopic       =   "Form1"
   ScaleHeight     =   3120
   ScaleWidth      =   3165
   Begin VB.CommandButton cmdExit 
      Caption         =   "Exit"
      Height          =   495
      Left            =   1680
      TabIndex        =   4
      Top             =   2400
      Width           =   1215
   End
   Begin VB.CommandButton cmdOK 
      Caption         =   "OK"
      Default         =   -1  'True
      Height          =   495
      Left            =   240
      TabIndex        =   2
      Top             =   2400
      Width           =   1215
   End
   Begin VB.TextBox txtDeposit 
      Height          =   285
      Left            =   960
      TabIndex        =   0
      Top             =   1080
      Width           =   1215
   End
   Begin VB.Label lblOutput 
      Alignment       =   2  'Center
      Caption         =   " "
      Height          =   495
      Left            =   120
      TabIndex        =   3
      Top             =   1680
      Width           =   2895
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Caption         =   "How much money will be deposited to open your account?"
      Height          =   495
      Left            =   240
      TabIndex        =   1
      Top             =   240
      Width           =   2655
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdExit_Click()
    End
End Sub

Private Sub txtDeposit_GotFocus()
    txtDeposit.SelStart = 0
    txtDeposit.SelLength = Len(txtDeposit.Text)
End Sub
