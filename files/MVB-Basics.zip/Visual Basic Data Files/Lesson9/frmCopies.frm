VERSION 5.00
Begin VB.Form frmMain 
   Caption         =   "Copy Store"
   ClientHeight    =   2445
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   3255
   LinkTopic       =   "Form1"
   ScaleHeight     =   2445
   ScaleWidth      =   3255
   StartUpPosition =   3  'Windows Default
   Begin VB.TextBox txtCopies 
      Height          =   285
      Left            =   1800
      TabIndex        =   4
      Top             =   360
      Width           =   1215
   End
   Begin VB.CommandButton cmdExit 
      Caption         =   "Exit"
      Height          =   495
      Left            =   1800
      TabIndex        =   3
      Top             =   1680
      Width           =   1215
   End
   Begin VB.CommandButton cmdOk 
      Caption         =   "OK"
      Height          =   495
      Left            =   240
      TabIndex        =   2
      Top             =   1680
      Width           =   1215
   End
   Begin VB.Label lblOutput 
      Height          =   255
      Left            =   120
      TabIndex        =   1
      Top             =   1080
      Width           =   3015
   End
   Begin VB.Label lblText1 
      AutoSize        =   -1  'True
      Caption         =   "Number of Copies:"
      Height          =   195
      Left            =   240
      TabIndex        =   0
      Top             =   405
      Width           =   1305
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdExit_Click()
    End
End Sub

Private Sub cmdOk_Click()

End Sub

Private Sub txtCopies_GotFocus()
    txtCopies.SelStart = 0
    txtCopies.SelLength = Len(txtCopies.Text)
End Sub
