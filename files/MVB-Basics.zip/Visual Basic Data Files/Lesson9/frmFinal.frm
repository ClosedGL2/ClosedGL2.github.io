VERSION 5.00
Begin VB.Form frmFinal 
   Caption         =   "Exempt from Final?"
   ClientHeight    =   3600
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   5355
   LinkTopic       =   "Form1"
   ScaleHeight     =   3600
   ScaleWidth      =   5355
   StartUpPosition =   3  'Windows Default
   Begin VB.TextBox txtAbsences 
      Alignment       =   1  'Right Justify
      Height          =   285
      Left            =   4320
      TabIndex        =   1
      Top             =   1080
      Width           =   735
   End
   Begin VB.CommandButton cmdExit 
      Cancel          =   -1  'True
      Caption         =   "Exit"
      Height          =   495
      Left            =   2880
      TabIndex        =   3
      Top             =   2880
      Width           =   975
   End
   Begin VB.CommandButton cmdOK 
      Caption         =   "OK"
      Default         =   -1  'True
      Height          =   495
      Left            =   1560
      TabIndex        =   2
      Top             =   2880
      Width           =   975
   End
   Begin VB.TextBox txtAverage 
      Alignment       =   1  'Right Justify
      Height          =   285
      Left            =   4320
      TabIndex        =   0
      Top             =   480
      Width           =   735
   End
   Begin VB.Label lblAbsent 
      AutoSize        =   -1  'True
      Caption         =   "How many days were you absent?"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   300
      Left            =   240
      TabIndex        =   6
      Top             =   1080
      Width           =   3600
   End
   Begin VB.Label lblResult 
      AutoSize        =   -1  'True
      BackColor       =   &H00C0C0C0&
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   300
      Left            =   120
      TabIndex        =   5
      Top             =   2280
      Visible         =   0   'False
      Width           =   5010
   End
   Begin VB.Label lblAverage 
      AutoSize        =   -1  'True
      Caption         =   "Enter your average:"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   300
      Left            =   240
      TabIndex        =   4
      Top             =   480
      Width           =   2070
   End
End
Attribute VB_Name = "frmFinal"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cmdExit_Click()
    End
End Sub

Private Sub cmdOK_Click()

End Sub

Private Sub txtAbsences_GotFocus()
    txtAbsences.SelStart = 0
    txtAbsences.SelLength = Len(txtAbsences.Text)
End Sub

Private Sub txtAverage_GotFocus()
    txtAverage.SelStart = 0
    txtAverage.SelLength = Len(txtAverage.Text)
End Sub
