VERSION 5.00
Begin VB.Form frmMain 
   Caption         =   "Weight"
   ClientHeight    =   3870
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4455
   LinkTopic       =   "Form1"
   ScaleHeight     =   3870
   ScaleWidth      =   4455
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton cmdExit 
      Caption         =   "Exit"
      Height          =   495
      Left            =   2880
      TabIndex        =   4
      Top             =   3240
      Width           =   1215
   End
   Begin VB.CommandButton cmdCalc 
      Caption         =   "Calculate"
      Height          =   495
      Left            =   720
      TabIndex        =   2
      Top             =   3240
      Width           =   1215
   End
   Begin VB.TextBox txtWeight 
      Height          =   285
      Left            =   1680
      TabIndex        =   0
      Top             =   480
      Width           =   1215
   End
   Begin VB.Label lblOutput 
      Alignment       =   2  'Center
      Height          =   255
      Left            =   480
      TabIndex        =   3
      Top             =   2760
      Width           =   3495
   End
   Begin VB.Label lblWeight 
      Alignment       =   2  'Center
      Caption         =   "Enter your Weight"
      Height          =   255
      Left            =   120
      TabIndex        =   1
      Top             =   120
      Width           =   4215
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdExit_Click()
    End
End Sub

Private Sub txtWeight_GotFocus()
    txtWeight.SelStart = 0
    txtWeight.SelLength = Len(txtWeight.Text)
End Sub
