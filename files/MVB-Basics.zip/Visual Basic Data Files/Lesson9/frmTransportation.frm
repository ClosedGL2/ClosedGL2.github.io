VERSION 5.00
Begin VB.Form frmMain 
   Caption         =   "Transportation"
   ClientHeight    =   2280
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   3855
   LinkTopic       =   "Form1"
   ScaleHeight     =   2280
   ScaleWidth      =   3855
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton cmdExit 
      Caption         =   "Exit"
      Height          =   495
      Left            =   2280
      TabIndex        =   3
      Top             =   1560
      Width           =   1215
   End
   Begin VB.CommandButton cmdOk 
      Caption         =   "OK"
      Height          =   495
      Left            =   480
      TabIndex        =   2
      Top             =   1560
      Width           =   1215
   End
   Begin VB.TextBox txtPassengers 
      Height          =   285
      Left            =   2160
      TabIndex        =   1
      Top             =   360
      Width           =   1215
   End
   Begin VB.Label lblOutput 
      Alignment       =   2  'Center
      Height          =   255
      Left            =   120
      TabIndex        =   4
      Top             =   960
      Width           =   3615
   End
   Begin VB.Label lblPassengers 
      AutoSize        =   -1  'True
      Caption         =   "Number of Passengers"
      Height          =   195
      Left            =   360
      TabIndex        =   0
      Top             =   405
      Width           =   1605
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdExit_Click()
    End
End Sub

Private Sub txtPassengers_GotFocus()
    txtPassengers.SelStart = 0
    txtPassengers.SelLength = Len(txtPassengers.Text)
End Sub
