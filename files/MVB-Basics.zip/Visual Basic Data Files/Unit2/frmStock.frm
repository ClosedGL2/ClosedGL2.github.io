VERSION 5.00
Begin VB.Form frmStock 
   Caption         =   "Stock Calculator"
   ClientHeight    =   2745
   ClientLeft      =   3825
   ClientTop       =   2880
   ClientWidth     =   4095
   LinkTopic       =   "Form1"
   ScaleHeight     =   2745
   ScaleWidth      =   4095
   Begin VB.CommandButton cmdExit 
      Caption         =   "Exit"
      Height          =   495
      Left            =   2760
      TabIndex        =   6
      Top             =   2040
      Width           =   1215
   End
   Begin VB.CommandButton cmdChange 
      Caption         =   "Percent Change"
      Enabled         =   0   'False
      Height          =   495
      Left            =   1440
      TabIndex        =   5
      Top             =   2040
      Width           =   1215
   End
   Begin VB.CommandButton cmdGainLoss 
      Caption         =   "Gain/Loss"
      Height          =   495
      Left            =   120
      TabIndex        =   4
      Top             =   2040
      Width           =   1215
   End
   Begin VB.TextBox txtOpen 
      Height          =   285
      Left            =   2280
      TabIndex        =   2
      Top             =   960
      Width           =   1215
   End
   Begin VB.TextBox txtClose 
      Height          =   285
      Left            =   2280
      TabIndex        =   3
      Top             =   1320
      Width           =   1215
   End
   Begin VB.TextBox txtShares 
      Height          =   285
      Left            =   2280
      TabIndex        =   1
      Top             =   600
      Width           =   1215
   End
   Begin VB.TextBox txtName 
      Height          =   285
      Left            =   2280
      TabIndex        =   0
      Top             =   240
      Width           =   1215
   End
   Begin VB.Label lblText4 
      AutoSize        =   -1  'True
      Caption         =   "Closing Price Per Share:"
      Height          =   195
      Left            =   240
      TabIndex        =   10
      Top             =   1365
      Width           =   1710
   End
   Begin VB.Label lblText3 
      AutoSize        =   -1  'True
      Caption         =   "Opening Price Per Share:"
      Height          =   195
      Left            =   240
      TabIndex        =   9
      Top             =   1005
      Width           =   1800
   End
   Begin VB.Label lblText2 
      AutoSize        =   -1  'True
      Caption         =   "Number of Shares:"
      Height          =   195
      Left            =   240
      TabIndex        =   8
      Top             =   645
      Width           =   1320
   End
   Begin VB.Label lblText1 
      AutoSize        =   -1  'True
      Caption         =   "Stock Name:"
      Height          =   195
      Left            =   240
      TabIndex        =   7
      Top             =   285
      Width           =   930
   End
End
Attribute VB_Name = "frmStock"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Private Sub cmdExit_Click()
  End
End Sub
