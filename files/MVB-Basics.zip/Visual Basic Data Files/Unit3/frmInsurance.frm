VERSION 5.00
Begin VB.Form frmMain 
   Caption         =   "Insurance"
   ClientHeight    =   4485
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   3450
   LinkTopic       =   "Form1"
   ScaleHeight     =   4485
   ScaleWidth      =   3450
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton cmdExit 
      Caption         =   "Exit"
      Height          =   495
      Left            =   1920
      TabIndex        =   4
      Top             =   3840
      Width           =   1215
   End
   Begin VB.CommandButton cmdOK 
      Caption         =   "OK"
      Height          =   495
      Left            =   240
      TabIndex        =   3
      Top             =   3840
      Width           =   1215
   End
   Begin VB.TextBox txtPayment 
      Height          =   285
      Left            =   1680
      TabIndex        =   1
      Top             =   240
      Width           =   1335
   End
   Begin VB.Label lblOutput 
      Alignment       =   2  'Center
      Height          =   255
      Left            =   120
      TabIndex        =   2
      Top             =   3360
      Width           =   3255
   End
   Begin VB.Label lblText1 
      AutoSize        =   -1  'True
      Caption         =   "Monthly Payment:"
      Height          =   195
      Left            =   240
      TabIndex        =   0
      Top             =   285
      Width           =   1260
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdExit_Click()
    End
End Sub

Private Sub txtPayment_GotFocus()
    txtPayment.SelStart = 0
    txtPayment.SelLength = Len(txtPayment.Text)
End Sub
