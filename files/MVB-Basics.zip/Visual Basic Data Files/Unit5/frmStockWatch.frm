VERSION 5.00
Begin VB.Form frmMain 
   Caption         =   "Stock Watch"
   ClientHeight    =   7545
   ClientLeft      =   1845
   ClientTop       =   855
   ClientWidth     =   7335
   DrawWidth       =   3
   LinkTopic       =   "Form1"
   ScaleHeight     =   7545
   ScaleWidth      =   7335
   Begin VB.TextBox txtDay3Low 
      Alignment       =   1  'Right Justify
      Height          =   285
      Left            =   5640
      TabIndex        =   7
      Top             =   2640
      Width           =   1215
   End
   Begin VB.TextBox txtDay3High 
      Alignment       =   1  'Right Justify
      Height          =   285
      Left            =   5640
      TabIndex        =   6
      Top             =   2160
      Width           =   1215
   End
   Begin VB.TextBox txtDay2Low 
      Alignment       =   1  'Right Justify
      Height          =   285
      Left            =   3840
      TabIndex        =   5
      Top             =   2640
      Width           =   1215
   End
   Begin VB.TextBox txtDay2High 
      Alignment       =   1  'Right Justify
      Height          =   285
      Left            =   3840
      TabIndex        =   4
      Top             =   2160
      Width           =   1215
   End
   Begin VB.TextBox txtDay1Low 
      Alignment       =   1  'Right Justify
      Height          =   285
      Left            =   2040
      TabIndex        =   3
      Top             =   2640
      Width           =   1215
   End
   Begin VB.TextBox txtDay1High 
      Alignment       =   1  'Right Justify
      Height          =   285
      Left            =   2040
      TabIndex        =   2
      Top             =   2160
      Width           =   1215
   End
   Begin VB.CommandButton cmdGraph 
      Caption         =   "Graph!"
      Default         =   -1  'True
      Height          =   495
      Left            =   5640
      TabIndex        =   8
      Top             =   240
      Width           =   1095
   End
   Begin VB.TextBox txtSymbol 
      Height          =   285
      Left            =   2280
      TabIndex        =   1
      Top             =   960
      Width           =   1215
   End
   Begin VB.TextBox txtName 
      Height          =   285
      Left            =   2280
      TabIndex        =   0
      Top             =   360
      Width           =   2415
   End
   Begin VB.Label lbl0 
      Alignment       =   1  'Right Justify
      AutoSize        =   -1  'True
      BackColor       =   &H00FFFFFF&
      Caption         =   "$0.00"
      Height          =   195
      Left            =   1125
      TabIndex        =   24
      Top             =   6360
      Width           =   405
   End
   Begin VB.Label lbl100 
      AutoSize        =   -1  'True
      BackColor       =   &H00FFFFFF&
      Caption         =   "$100.00"
      Height          =   195
      Left            =   960
      TabIndex        =   23
      Top             =   4080
      Width           =   585
   End
   Begin VB.Label lblDay3Graph 
      AutoSize        =   -1  'True
      BackColor       =   &H00FFFFFF&
      Caption         =   "Day 3"
      Height          =   195
      Left            =   5640
      TabIndex        =   22
      Top             =   6720
      Width           =   420
   End
   Begin VB.Label lblDay2Graph 
      AutoSize        =   -1  'True
      BackColor       =   &H00FFFFFF&
      Caption         =   "Day 2"
      Height          =   195
      Left            =   3720
      TabIndex        =   21
      Top             =   6720
      Width           =   420
   End
   Begin VB.Label lblDay1Graph 
      AutoSize        =   -1  'True
      BackColor       =   &H00FFFFFF&
      Caption         =   "Day 1"
      Height          =   195
      Left            =   1800
      TabIndex        =   20
      Top             =   6720
      Width           =   420
   End
   Begin VB.Label lblDay3 
      AutoSize        =   -1  'True
      Caption         =   "Day 3"
      Height          =   195
      Left            =   6000
      TabIndex        =   19
      Top             =   1680
      Width           =   420
   End
   Begin VB.Label lblDay2 
      AutoSize        =   -1  'True
      Caption         =   "Day 2"
      Height          =   195
      Left            =   4200
      TabIndex        =   18
      Top             =   1680
      Width           =   420
   End
   Begin VB.Label lblDay1 
      AutoSize        =   -1  'True
      Caption         =   "Day 1"
      Height          =   195
      Left            =   2400
      TabIndex        =   17
      Top             =   1680
      Width           =   420
   End
   Begin VB.Label lblLow 
      AutoSize        =   -1  'True
      Caption         =   "Low Price"
      Height          =   195
      Left            =   360
      TabIndex        =   16
      Top             =   2640
      Width           =   705
   End
   Begin VB.Label lblHigh 
      AutoSize        =   -1  'True
      Caption         =   "High Price"
      Height          =   195
      Left            =   360
      TabIndex        =   15
      Top             =   2160
      Width           =   735
   End
   Begin VB.Label lblError 
      AutoSize        =   -1  'True
      BackColor       =   &H00FFFFFF&
      Caption         =   "No Financial Data Entered"
      Height          =   195
      Left            =   3000
      TabIndex        =   14
      Top             =   5640
      Visible         =   0   'False
      Width           =   1875
   End
   Begin VB.Label lblSymbolPrompt 
      AutoSize        =   -1  'True
      Caption         =   "Enter the Stock Symbol:"
      Height          =   195
      Left            =   240
      TabIndex        =   13
      Top             =   960
      Width           =   1710
   End
   Begin VB.Label lblPromptName 
      AutoSize        =   -1  'True
      Caption         =   "Enter the Company Name:"
      Height          =   195
      Left            =   240
      TabIndex        =   12
      Top             =   360
      Width           =   1860
   End
   Begin VB.Label lblTitle 
      AutoSize        =   -1  'True
      BackColor       =   &H00FFFFFF&
      Caption         =   "Name of Company (Symbol)"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   240
      Left            =   2610
      TabIndex        =   11
      Top             =   3600
      Visible         =   0   'False
      Width           =   2535
   End
   Begin VB.Label lblY 
      BackColor       =   &H00FFFFFF&
      Caption         =   "Time"
      Height          =   255
      Left            =   3720
      TabIndex        =   10
      Top             =   6960
      Width           =   375
   End
   Begin VB.Label lblX 
      BackColor       =   &H00FFFFFF&
      Caption         =   "Stock Price (U.S. Dollars)"
      Height          =   495
      Left            =   360
      TabIndex        =   9
      Top             =   5160
      Width           =   975
   End
   Begin VB.Line linYAxis 
      BorderColor     =   &H00000000&
      BorderWidth     =   3
      X1              =   1680
      X2              =   6120
      Y1              =   6480
      Y2              =   6480
   End
   Begin VB.Line linXAxis 
      BorderColor     =   &H00000000&
      BorderWidth     =   3
      X1              =   1680
      X2              =   1680
      Y1              =   4080
      Y2              =   6480
   End
   Begin VB.Shape shpBackground 
      FillColor       =   &H00FFFFFF&
      FillStyle       =   0  'Solid
      Height          =   3975
      Left            =   240
      Top             =   3360
      Width           =   6855
   End
   Begin VB.Menu mnuFile 
      Caption         =   "File"
      Begin VB.Menu mnuFileExit 
         Caption         =   "Exit"
      End
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cmdGraph_Click()
    Dim lngXCoordinate1 As Long
    Dim lngYCoordinate1 As Long
    Dim lngXCoordinate2 As Long
    Dim lngYCoordinate2 As Long
    Dim lngXCoordinate3 As Long
    Dim lngYCoordinate3 As Long

    'Clear previous graphs
    Line (1730, 4080)-(6360, 6420), vbWhite, BF

    'Make sure values have been entered in all fields
    If txtName.Text = "" Then
        MsgBox "You have not entered valid company information."
        txtName.SelStart = 0
        txtName.SelLength = Len(txtName.Text)
        txtName.SetFocus
    Else
        If txtSymbol.Text = "" Then
            MsgBox "You have not entered valid symbol information."
            txtSymbol.SelStart = 0
            txtSymbol.SelLength = Len(txtSymbol.Text)
            txtSymbol.SetFocus
        Else
            'Make sure values are in the correct range
            If Val(txtDay1High.Text) > 100 Or Val(txtDay1High.Text) < 0 Then
                MsgBox "Values must be between 0 and 100."
                txtDay1High.SetFocus
            Else
                If Val(txtDay1Low.Text) > 100 Or Val(txtDay1Low.Text) < 0 Then
                    MsgBox "Values must be between 0 and 100."
                    txtDay1Low.SetFocus
                Else
                    If Val(txtDay2High.Text) > 100 Or Val(txtDay2High.Text) < 0 Then
                        MsgBox "Values must be between 0 and 100."
                        txtDay2High.SetFocus
                    Else
                        If Val(txtDay2Low.Text) > 100 Or Val(txtDay2Low.Text) < 0 Then
                            MsgBox "Values must be between 0 and 100."
                            txtDay2Low.SetFocus
                        Else
                            If Val(txtDay3High.Text) > 100 Or Val(txtDay3High.Text) < 0 Then
                                MsgBox "Values must be between 0 and 100."
                                txtDay3High.SetFocus
                            Else
                                If Val(txtDay3Low.Text) > 100 Or Val(txtDay3Low.Text) < 0 Then
                                    MsgBox "Values must be between 0 and 100."
                                    txtDay3Low.SetFocus
                                Else
                                    'Center the title on the graph and display it
            
                                    'Get coordinates for Day1 High
           
                                    'Draw line connecting Highs
        
                                    'Graph Day1 Low
                                  
                                End If
                            End If
                        End If
                    End If
                End If
            End If
        End If
    End If
End Sub

Private Sub txtDay1High_GotFocus()
    txtDay1High.SelStart = 0
    txtDay1High.SelLength = Len(txtDay1High.Text)
End Sub

Private Sub txtDay2High_GotFocus()
    txtDay2High.SelStart = 0
    txtDay2High.SelLength = Len(txtDay2High.Text)
End Sub

Private Sub txtDay3High_GotFocus()
    txtDay3High.SelStart = 0
    txtDay3High.SelLength = Len(txtDay3High.Text)
End Sub

Private Sub txtDay1Low_GotFocus()
    txtDay1Low.SelStart = 0
    txtDay1Low.SelLength = Len(txtDay1Low.Text)
End Sub

Private Sub txtDay2Low_GotFocus()
    txtDay2Low.SelStart = 0
    txtDay2Low.SelLength = Len(txtDay2Low.Text)
End Sub

Private Sub txtDay3Low_GotFocus()
    txtDay3Low.SelStart = 0
    txtDay3Low.SelLength = Len(txtDay3Low.Text)
End Sub
