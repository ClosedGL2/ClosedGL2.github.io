VERSION 5.00
Begin VB.Form MainWindow 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Minecraft Horter Horse Sorter Calculator"
   ClientHeight    =   2310
   ClientLeft      =   11505
   ClientTop       =   6780
   ClientWidth     =   5190
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   2310
   ScaleWidth      =   5190
   Begin VB.CommandButton cmdWhatIsHorter 
      Caption         =   "What is a Horter?"
      Height          =   375
      Left            =   120
      TabIndex        =   4
      Top             =   1800
      Width           =   4935
   End
   Begin VB.CommandButton cmdCalculate 
      Caption         =   "Calculate"
      Default         =   -1  'True
      Height          =   615
      Left            =   3600
      TabIndex        =   3
      Top             =   240
      Width           =   1455
   End
   Begin VB.CommandButton cmdNumRowsHelp 
      Caption         =   "?"
      Height          =   255
      Left            =   3120
      TabIndex        =   6
      Top             =   600
      Width           =   255
   End
   Begin VB.TextBox txtNumRows 
      Height          =   285
      Left            =   1800
      TabIndex        =   2
      Text            =   "5"
      Top             =   600
      Width           =   1215
   End
   Begin VB.CommandButton cmdPenLengthHelp 
      Caption         =   "?"
      Height          =   255
      Left            =   3120
      TabIndex        =   5
      Top             =   240
      Width           =   255
   End
   Begin VB.TextBox txtPenLength 
      Height          =   285
      Left            =   1800
      TabIndex        =   1
      Text            =   "3"
      Top             =   240
      Width           =   1215
   End
   Begin VB.Label lblDelay 
      Alignment       =   2  'Center
      Caption         =   "Marker redstone delay:"
      Height          =   255
      Left            =   120
      TabIndex        =   9
      Top             =   1080
      Width           =   4935
   End
   Begin VB.Label lblDistance 
      Alignment       =   2  'Center
      Caption         =   "Distance from end marker to tripwire:"
      Height          =   255
      Left            =   120
      TabIndex        =   8
      Top             =   1440
      Width           =   4935
   End
   Begin VB.Label Label2 
      Alignment       =   1  'Right Justify
      Caption         =   "# of pen rows:"
      Height          =   255
      Left            =   240
      TabIndex        =   7
      Top             =   600
      Width           =   1455
   End
   Begin VB.Label Label1 
      Alignment       =   1  'Right Justify
      Caption         =   "Length inside pens:"
      Height          =   255
      Left            =   240
      TabIndex        =   0
      Top             =   240
      Width           =   1455
   End
End
Attribute VB_Name = "MainWindow"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim intPenLength As Long
Dim intNumRows As Long
Dim intDelay As Long
Dim intDistance As Long

Private Sub cmdCalculate_Click()
    Dim blnLegalInput As Boolean
    blnLegalInput = True

    ' get values
    intPenLength = Val(txtPenLength.Text)
    intNumRows = Val(txtNumRows.Text)
    
    ' check if input is ok
    If intPenLength < 2 Then
        blnLegalInput = False
        MsgBox ("Length inside pens must be at least 2 for the horses to fit")
    End If
    If intNumRows < 2 Then
        blnLegalInput = False
        MsgBox ("There must be at least 2 pen rows for the speed test to mean anything")
    End If

    If blnLegalInput Then
        secs = ((intPenLength + 4) * intNumRows) / 9.675

        ' calculate ticks
        intDelay = (secs * 10) - 2
    
        ' calculate distance
        intDistance = secs * 14.5125
    
        ' display values
        lblDelay.Caption = "Marker redstone delay: " & Str(intDelay) & " ticks"
        lblDistance.Caption = "Distance from end marker to tripwire: " & Str(intDistance) & " blocks"
    End If
End Sub

Private Sub cmdNumRowsHelp_Click()
    frmNumRowsHelp.Show
End Sub

Private Sub cmdPenLengthHelp_Click()
    frmPenLengthHelp.Show
End Sub

Private Sub cmdWhatIsHorter_Click()
    frmWhatIsHorter.Show
End Sub

Private Sub txtNumRows_GotFocus()
    txtNumRows.SelStart = 0
    txtNumRows.SelLength = Len(txtNumRows.Text)
End Sub

Private Sub txtPenLength_GotFocus()
    txtPenLength.SelStart = 0
    txtPenLength.SelLength = Len(txtPenLength.Text)
End Sub


