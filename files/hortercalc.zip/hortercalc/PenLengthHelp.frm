VERSION 5.00
Begin VB.Form frmPenLengthHelp 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Length Inside Pens"
   ClientHeight    =   3720
   ClientLeft      =   10710
   ClientTop       =   5520
   ClientWidth     =   6210
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3720
   ScaleWidth      =   6210
   Begin VB.CommandButton cmdClose 
      Caption         =   "Close"
      Default         =   -1  'True
      Height          =   375
      Left            =   4800
      TabIndex        =   3
      Top             =   3120
      Width           =   1215
   End
   Begin VB.Label Label3 
      Caption         =   "In this example, the length inside the pens is 3 blocks."
      Height          =   495
      Left            =   3240
      TabIndex        =   2
      Top             =   1320
      Width           =   2655
   End
   Begin VB.Label Label2 
      Caption         =   "The length of the inside of each pen, in blocks."
      Height          =   495
      Left            =   3240
      TabIndex        =   1
      Top             =   720
      Width           =   2655
   End
   Begin VB.Label Label1 
      Caption         =   "Length Inside Pens"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   12.75
         Charset         =   0
         Weight          =   700
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   3240
      TabIndex        =   0
      Top             =   240
      Width           =   2655
   End
   Begin VB.Image Image1 
      Height          =   3225
      Left            =   240
      Picture         =   "PenLengthHelp.frx":0000
      Top             =   240
      Width           =   2805
   End
End
Attribute VB_Name = "frmPenLengthHelp"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdClose_Click()
    Unload Me
End Sub
