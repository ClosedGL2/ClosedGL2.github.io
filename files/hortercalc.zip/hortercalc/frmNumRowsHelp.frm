VERSION 5.00
Begin VB.Form frmNumRowsHelp 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Number of Pen Rows"
   ClientHeight    =   3720
   ClientLeft      =   10710
   ClientTop       =   5520
   ClientWidth     =   6225
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3720
   ScaleWidth      =   6225
   Begin VB.CommandButton cmdClose 
      Caption         =   "Close"
      Default         =   -1  'True
      Height          =   375
      Left            =   4800
      TabIndex        =   3
      Top             =   3120
      Width           =   1215
   End
   Begin VB.Label Label3 
      Caption         =   "In this example, there are 5 pen rows."
      Height          =   255
      Left            =   3240
      TabIndex        =   2
      Top             =   1320
      Width           =   2775
   End
   Begin VB.Label Label2 
      Caption         =   "The number of rows of speed pens in the Horter."
      Height          =   495
      Left            =   3240
      TabIndex        =   1
      Top             =   720
      Width           =   2775
   End
   Begin VB.Label Label1 
      Caption         =   "Number of Pen Rows"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   12.75
         Charset         =   0
         Weight          =   700
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   3240
      TabIndex        =   0
      Top             =   240
      Width           =   2775
   End
   Begin VB.Image Image1 
      Height          =   3225
      Left            =   240
      Picture         =   "frmNumRowsHelp.frx":0000
      Top             =   240
      Width           =   2805
   End
End
Attribute VB_Name = "frmNumRowsHelp"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdClose_Click()
    Unload Me
End Sub

