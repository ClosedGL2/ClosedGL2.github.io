VERSION 5.00
Begin VB.Form frmWhatIsHorter 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "About the Horter"
   ClientHeight    =   5280
   ClientLeft      =   9270
   ClientTop       =   4425
   ClientWidth     =   9045
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   5280
   ScaleWidth      =   9045
   Begin VB.CommandButton cmdClose 
      Caption         =   "Close"
      Default         =   -1  'True
      Height          =   375
      Left            =   7560
      TabIndex        =   8
      Top             =   4680
      Width           =   1215
   End
   Begin VB.TextBox Text2 
      BackColor       =   &H8000000F&
      Height          =   285
      Left            =   4680
      Locked          =   -1  'True
      TabIndex        =   4
      Text            =   "https://yewtu.be/rJIrjeVh-bE"
      Top             =   3720
      Width           =   4095
   End
   Begin VB.TextBox Text1 
      BackColor       =   &H8000000F&
      Height          =   285
      Left            =   4680
      Locked          =   -1  'True
      TabIndex        =   3
      Text            =   "https://yewtu.be/r4YtjxNzrMg"
      Top             =   2760
      Width           =   4095
   End
   Begin VB.Label Label6 
      Caption         =   "Jake's videos about the Horter:"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4680
      TabIndex        =   7
      Top             =   2160
      Width           =   4095
   End
   Begin VB.Label Label5 
      Caption         =   "The Horter Part 2: Adjusting Pen Length and Number of Speed Rows"
      Height          =   495
      Left            =   4680
      TabIndex        =   6
      Top             =   3240
      Width           =   4095
   End
   Begin VB.Label Label4 
      Caption         =   "The Horter - Minecraft Horse Sorting Tutorial"
      Height          =   255
      Left            =   4680
      TabIndex        =   5
      Top             =   2520
      Width           =   4095
   End
   Begin VB.Label Label3 
      Caption         =   $"frmWhatIsHorter.frx":0000
      Height          =   615
      Left            =   4680
      TabIndex        =   2
      Top             =   1320
      Width           =   4095
   End
   Begin VB.Label Label2 
      Caption         =   "The Horter is a Minecraft horse sorter designed by the Minecraft YouTuber Jake Eyes, aka jayRiott."
      Height          =   495
      Left            =   4680
      TabIndex        =   1
      Top             =   720
      Width           =   4095
   End
   Begin VB.Label Label1 
      Caption         =   "The Horter"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   12.75
         Charset         =   0
         Weight          =   700
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   4680
      TabIndex        =   0
      Top             =   240
      Width           =   4095
   End
   Begin VB.Image Image1 
      Height          =   4770
      Left            =   240
      Picture         =   "frmWhatIsHorter.frx":008A
      Top             =   240
      Width           =   4230
   End
End
Attribute VB_Name = "frmWhatIsHorter"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdClose_Click()
    Unload Me
End Sub
